# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Scope-bound built-in contexts over one SQLAlchemy async database."""

from __future__ import annotations

import asyncio
import json
import logging
import secrets
from collections.abc import Awaitable, Callable, Mapping
from contextlib import AbstractContextManager, nullcontext
from dataclasses import dataclass, replace
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, cast
from uuid import uuid4

from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError
from jsonschema.exceptions import ValidationError as JsonSchemaValidationError
from jsonschema.protocols import Validator
from referencing import Registry
from referencing.exceptions import Unresolvable
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncConnection

from powercontext.artifacts import Artifact, ArtifactRef, MemoryCitation
from powercontext.builtin.artifacts.experience import (
    EXPERIENCE_INCUBATION_CURSOR_NAME,
    Experience,
    ExperienceCandidateInput,
    ExperienceCandidatePipeline,
    ExperienceContent,
    ExperienceGenerator,
    ExperienceSearchHit,
    ExperienceSearchOutcome,
)
from powercontext.builtin.artifacts.handoff import (
    ActivateHandoff,
    Handoff,
    HandoffActivation,
    HandoffEvidenceUnavailableError,
    HandoffGenerationPipeline,
    HandoffService,
    HandoffSourceCitation,
)
from powercontext.builtin.artifacts.handoff.generation_metadata import HandoffGenerationReceipts
from powercontext.builtin.artifacts.memory import (
    CandidatePipeline,
    EmbeddingProfile,
    Memory,
    MemoryCapacityBudget,
    MemoryCompactionPolicy,
    MemoryQueryEmbedding,
    MemoryReranker,
    MemoryService,
    MemoryWriteGate,
    MemoryWritePlan,
    MemoryWriteVerdict,
)
from powercontext.builtin.artifacts.profile import Profile
from powercontext.builtin.artifacts.profile.management import ProfileManagementWriter
from powercontext.builtin.artifacts.profile.models import ProfileCandidateProposal
from powercontext.builtin.artifacts.profile.service import RelationalProfileService
from powercontext.builtin.artifacts.prompt import Prompt, PromptRegistry
from powercontext.builtin.artifacts.prompt.builtin import builtin_prompt_definitions
from powercontext.builtin.artifacts.prompt.service import (
    DemonstrationGenerator,
    PromptService,
    ScopedPrompts,
    current_prompt,
    prompt_operation,
)
from powercontext.builtin.artifacts.search import AdmissionFloor
from powercontext.builtin.artifacts.skill import (
    ExternalSkillProvider,
    ExternalSkillRegistryUnavailableError,
    Skill,
    SkillContent,
    SkillGenerator,
    SkillOrigin,
    SkillOriginKind,
    SkillPackageRef,
    SkillPackageSnapshot,
    SkillSearchHit,
    capture_skill_archive,
)
from powercontext.builtin.artifacts.skill.distribution import RemoteSkillDistributionService
from powercontext.builtin.artifacts.skill.publication import ManagedSkillPublicationService
from powercontext.builtin.artifacts.skill.registry import ExternalSkillRegistryService
from powercontext.builtin.artifacts.topic_memory import (
    TOPIC_MEMORY_SOURCE_WINDOW_BINDING,
    PublishedTopicMemory,
    TopicMemory,
    TopicMemoryBrowseCursor,
    TopicMemoryCurrentItem,
    TopicMemorySearchMode,
    TopicMemorySearchResult,
)
from powercontext.builtin.context import BuiltinArtifacts, BuiltinSources
from powercontext.builtin.dream.generation import DreamGenerator
from powercontext.builtin.dream.models import DreamBudget, DreamOperation
from powercontext.builtin.dream.service import CandidateAttester, DreamAuthorizer, DreamService
from powercontext.builtin.evidence.resolver import AuthorizationContext, EvidenceAuthorizer, EvidenceResolver
from powercontext.builtin.inference import EmbeddingModel, InferenceUsage, InvalidInferenceOutputError, TokenEstimator
from powercontext.builtin.persistence.agent_skill_targets import RemoteAgentSkillTargetRepository
from powercontext.builtin.persistence.artifact_governance import (
    ArtifactGovernance,
    ArtifactGovernanceRepository,
    ArtifactLifecycleState,
)
from powercontext.builtin.persistence.artifact_readers import TopicMemoryArtifactListReader
from powercontext.builtin.persistence.artifacts import ArtifactRepository
from powercontext.builtin.persistence.candidates import CandidateRepository
from powercontext.builtin.persistence.connectors import ConnectorCheckpointRepository
from powercontext.builtin.persistence.cursors import SourceCursorRepository
from powercontext.builtin.persistence.database import AsyncDatabase
from powercontext.builtin.persistence.errors import RepositoryNotFoundError, StoredPayloadConflictError
from powercontext.builtin.persistence.experience_index import ExperienceIndex, NoExperienceIndex
from powercontext.builtin.persistence.external_skills import ExternalSkillRepository
from powercontext.builtin.persistence.family_management import (
    ExperienceManagementWriter,
    FamilyManagementWriterRegistry,
    HandoffManagementWriter,
    MemoryManagementWriter,
    PromptManagementWriter,
    SkillManagementWriter,
)
from powercontext.builtin.persistence.generation_sources import GenerationSourceAccess
from powercontext.builtin.persistence.handoff import (
    RelationalHandoffBackend,
    RelationalHandoffEvidenceResolver,
)
from powercontext.builtin.persistence.memory import RelationalMemoryBackend
from powercontext.builtin.persistence.memory_index import MemoryIndex, NoMemoryIndex
from powercontext.builtin.persistence.processing import ArtifactProcessingPendingRepository
from powercontext.builtin.persistence.processing_intents import ArtifactProcessingIntentRepository
from powercontext.builtin.persistence.records import RelationalRecordService
from powercontext.builtin.persistence.recurrence import RecurrenceRepository
from powercontext.builtin.persistence.skill_packages import SkillPackageRepository
from powercontext.builtin.persistence.skill_publications import SkillPublicationRepository
from powercontext.builtin.persistence.source_definitions import SourceDefinitionManifestRepository
from powercontext.builtin.persistence.sources import SourceRepository, StoredSource
from powercontext.builtin.persistence.statistics import StatisticsRepository
from powercontext.builtin.persistence.supervision import (
    ArtifactProcessingBindingStateRepository,
    ArtifactProcessingLeaseRepository,
)
from powercontext.builtin.persistence.tables import ARTIFACT_HEADS_TABLE, SOURCE_JOURNAL_HEADS_TABLE
from powercontext.builtin.persistence.topic_memory import TopicMemoryRepository
from powercontext.builtin.persistence.topic_memory_index import NoTopicMemoryIndex, TopicMemoryIndex
from powercontext.builtin.persistence.topic_memory_management import TopicMemoryManagementWriter
from powercontext.builtin.publication import ArtifactPublicationApplication
from powercontext.builtin.review.generation import (
    GeneratedCandidateResult,
    GenerationCapabilityUnavailableError,
    ReviewedGenerationService,
    SkillGenerationOrigin,
)
from powercontext.builtin.review.models import ArtifactCandidate
from powercontext.builtin.review.service import ReviewService
from powercontext.builtin.runtime._model_usage import _ModelUsageRecorder
from powercontext.builtin.runtime.decision_model import DecisionModel
from powercontext.builtin.runtime.models import (
    CommitConnectorCheckpoint,
    ConnectorCheckpointState,
    ExperienceIncubationResult,
    MemoryFlushResult,
    SourceReceipt,
    SubmitSourceObservation,
)
from powercontext.builtin.runtime.prepared_context import PreparedContextBuild
from powercontext.builtin.runtime.protocols import (
    BuiltinTriggers,
    RuntimeSpan,
    RuntimeTracing,
    TraceAttribute,
)
from powercontext.builtin.runtime.recall import RelationalRecallTokenEstimator
from powercontext.builtin.runtime.recurrence import RelationalRecurrenceLedger
from powercontext.builtin.runtime.statistics import RelationalScopedStatistics
from powercontext.builtin.scope import ScopeApplication
from powercontext.builtin.scope.subject_sources import SubjectSourceService
from powercontext.builtin.source_eligibility import is_generation_eligible, require_source_eligible
from powercontext.builtin.sources import (
    BUILTIN_SOURCE_REGISTRY,
    EXTERNAL_SKILL_SNAPSHOT_SOURCE_ADAPTER,
    SKILL_PACKAGE_UPLOAD_SOURCE_ADAPTER,
    SKILL_USAGE_SOURCE_ADAPTER,
    ExternalSkillImportMode,
    ExternalSkillSnapshotCapture,
    ExternalSkillSnapshotSource,
    SkillPackageUploadCapture,
    SkillUsageCapture,
    SourceCursor,
    SourceJournalEntry,
    validate_scope_id,
)
from powercontext.builtin.statistics import ModelUsageOperation, ModelUsagePurpose, RecallTokenMeasurement
from powercontext.builtin.triggers import (
    HANDOFF_BOUNDARY_TRIGGER_NAME,
    SOURCE_WINDOW_TRIGGER_NAME,
    HandoffBoundary,
    HandoffTrigger,
    ProcessSourceWindow,
    SourceHighWatermark,
    SourceWindowTrigger,
)
from powercontext.context import PowerContext
from powercontext.errors import (
    ArtifactNotFoundError,
    InvalidSourceDefinitionError,
    InvalidSourceObservationError,
    SourceConflictError,
    SourceDefinitionNotFoundError,
    SourceNotFoundError,
)
from powercontext.limits import MAX_SOURCE_OBSERVATION_BYTES
from powercontext.sources import (
    TEXT_EVIDENCE_PROJECTION_KEY,
    ConnectorBinding,
    Source,
    SourceCatalog,
    SourceDefinitionManifest,
    SourceDefinitionRegistry,
    SourceObservation,
    SourceProjectionKey,
    SourceRef,
    TextEvidence,
)

IdFactory = Callable[[str], str]
logger = logging.getLogger(__name__)


if TYPE_CHECKING:
    from powercontext.builtin.runtime.processing_execution import ScopeInvocation


MemorySnapshotAuthorizer = Callable[[Memory | None], Awaitable[None]]
MemoryCommitHook = Callable[[AsyncConnection, Memory | None, Memory | None], Awaitable[None]]
ExperienceCommitHook = Callable[[AsyncConnection, tuple[ArtifactCandidate[ExperienceContent], ...]], Awaitable[None]]


def _artifact_identity(ref: ArtifactRef) -> tuple[str, str, int]:
    return ref.family, ref.artifact_id, ref.revision


_MEMORY_COMMIT_STAGE = "memory.commit"
_MEMORY_COMMIT_MEMORY_CHANGED = "powercontext.memory.commit.memory_changed"
_MEMORY_COMMIT_ENTRY_VERSION_COUNT = "powercontext.memory.commit.entry_version_count"


@dataclass(frozen=True, slots=True)
class _Repositories:
    """Repositories shared by every scoped context."""

    sources: SourceRepository
    artifacts: ArtifactRepository
    governance: ArtifactGovernanceRepository
    candidates: CandidateRepository
    connector_checkpoints: ConnectorCheckpointRepository
    source_definitions: SourceDefinitionManifestRepository
    cursors: SourceCursorRepository
    external_skills: ExternalSkillRepository
    skill_packages: SkillPackageRepository
    agent_skill_targets: RemoteAgentSkillTargetRepository
    skill_publications: SkillPublicationRepository
    statistics: StatisticsRepository
    recurrence: RecurrenceRepository
    processing_pending: ArtifactProcessingPendingRepository
    processing_leases: ArtifactProcessingLeaseRepository
    processing_binding_states: ArtifactProcessingBindingStateRepository
    topic_memories: TopicMemoryRepository


@dataclass(frozen=True, slots=True)
class _ScopedServices:
    """Centralize relational service wiring for one scope."""

    database: AsyncDatabase
    scope_id: str
    repositories: _Repositories
    index: MemoryIndex
    experience_index: ExperienceIndex
    candidate_pipeline: CandidatePipeline | None
    experience_pipeline: ExperienceCandidatePipeline | None
    experience_generator: ExperienceGenerator | None
    skill_generator: SkillGenerator | None
    handoff_pipeline: HandoffGenerationPipeline | None
    embedding_model: EmbeddingModel | None
    memory_reranker: MemoryReranker | None
    memory_rerank_candidate_limit: int
    decision_model: DecisionModel | None
    memory_write_gate: MemoryWriteGate | None
    memory_capacity_budget: MemoryCapacityBudget
    memory_compaction: MemoryCompactionPolicy
    memory_max_history_revisions: int
    id_factory: IdFactory
    handoff_artifact_id: str
    memory_artifact_id: str
    source_lock: asyncio.Lock
    token_estimator: TokenEstimator | None
    source_registry: SourceDefinitionRegistry
    prompts: PromptService
    generation_receipts: HandoffGenerationReceipts
    model_usage: _ModelUsageRecorder

    def generation_sources(self) -> GenerationSourceAccess:
        return GenerationSourceAccess(self.repositories.sources)

    def sources(
        self,
        connection: AsyncConnection | None = None,
    ) -> tuple[_RelationalSources, SourceCatalog]:
        backend = _RelationalSources(
            database=self.database,
            scope_id=self.scope_id,
            registry=self.source_registry,
            repository=self.repositories.sources,
            processing_pending=self.repositories.processing_pending,
            write_lock=self.source_lock,
            connection=connection,
        )
        return backend, SourceCatalog(backend=backend, registry=self.source_registry)

    def memory(
        self,
        source_resolver: SourceCatalog,
        connection: AsyncConnection | None = None,
    ) -> MemoryService:
        return MemoryService(
            prompt_context=ScopedPrompts(self.prompts, self.scope_id),
            backend=RelationalMemoryBackend(
                database=self.database,
                scope_id=self.scope_id,
                artifacts=self.repositories.artifacts,
                index=self.index,
                connection=connection,
            ),
            candidate_pipeline=self.candidate_pipeline,
            embedding_model=self.embedding_model,
            reranker=self.memory_reranker,
            rerank_candidate_limit=self.memory_rerank_candidate_limit,
            capacity_budget=self.memory_capacity_budget,
            compaction=self.memory_compaction,
            max_history_revisions=self.memory_max_history_revisions,
            source_resolver=_RelationalMemorySourceResolver(
                database=self.database,
                scope_id=self.scope_id,
                catalog=source_resolver,
                access=self.generation_sources(),
                connection=connection,
            ),
            artifact_resolver=_RelationalArtifactResolver(
                database=self.database,
                scope_id=self.scope_id,
                repository=self.repositories.artifacts,
                connection=connection,
            ),
            id_factory=self.id_factory,
            write_gate=self.memory_write_gate,
        )

    def evidence(self, authorize: EvidenceAuthorizer | None = None) -> EvidenceResolver:
        async def read_memory(connection: AsyncConnection, citation: MemoryCitation):
            _, catalog = self.sources(connection)
            return await self.memory(catalog, connection).validate_citation(citation)

        return EvidenceResolver(
            scope_id=self.scope_id,
            sources=self.repositories.sources,
            artifacts=self.repositories.artifacts,
            memory_reader=read_memory,
            authorize=authorize,
            source_projector=lambda source: json.dumps(
                self.source_registry.project(source, TEXT_EVIDENCE_PROJECTION_KEY),
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ),
        )

    def review(self, connection: AsyncConnection | None = None) -> ReviewService:
        return ReviewService(
            database=self.database,
            scope_id=self.scope_id,
            candidates=self.repositories.candidates,
            artifacts=self.repositories.artifacts,
            experience_index=self.experience_index,
            skill_packages=self.repositories.skill_packages,
            sources=self.generation_sources(),
            id_factory=self.id_factory,
            evidence=self.evidence(),
            connection=connection,
        )

    def recurrence_ledger(self) -> RelationalRecurrenceLedger:
        """Return the only writer of the recurrence ledger."""

        return RelationalRecurrenceLedger(
            database=self.database,
            scope_id=self.scope_id,
            sources=self.repositories.sources,
            artifacts=self.repositories.artifacts,
            recurrence=self.repositories.recurrence,
            evidence=self.evidence(),
        )

    def generation(self) -> ReviewedGenerationService:
        return ReviewedGenerationService(
            prompt_context=ScopedPrompts(self.prompts, self.scope_id),
            database=self.database,
            scope_id=self.scope_id,
            sources=self.generation_sources(),
            artifacts=self.repositories.artifacts,
            review=self.review(),
            experience_generator=self.experience_generator,
            skill_generator=self.skill_generator,
        )

    def handoff(
        self,
        source_resolver: SourceCatalog,
    ) -> HandoffService:
        memory = self.memory(source_resolver)

        def evidence_resolver(scope_id: str) -> RelationalHandoffEvidenceResolver:
            services = self if scope_id == self.scope_id else replace(self, scope_id=scope_id)
            _, catalog = services.sources()
            return RelationalHandoffEvidenceResolver(
                database=services.database,
                scope_id=scope_id,
                sources=services.generation_sources(),
                artifacts=services.repositories.artifacts,
                memory=services.memory(catalog),
            )

        return HandoffService(
            generation_receipts=self.generation_receipts,
            prompt_context=ScopedPrompts(self.prompts, self.scope_id),
            scope_id=self.scope_id,
            artifact_id=self.handoff_artifact_id,
            backend=RelationalHandoffBackend(
                database=self.database,
                scope_id=self.scope_id,
                artifacts=self.repositories.artifacts,
            ),
            evidence_resolver=RelationalHandoffEvidenceResolver(
                database=self.database,
                scope_id=self.scope_id,
                sources=self.generation_sources(),
                artifacts=self.repositories.artifacts,
                memory=memory,
            ),
            evidence_resolver_for_scope=evidence_resolver,
            generation_pipeline=self.handoff_pipeline,
        )

    def statistics(self) -> RelationalScopedStatistics:
        """Return the scoped statistics service over shared repositories."""

        def memory_service(connection: AsyncConnection) -> MemoryService:
            _, source_catalog = self.sources(connection)
            return self.memory(source_catalog, connection)

        return RelationalScopedStatistics(
            database=self.database,
            scope_id=self.scope_id,
            memory_artifact_id=self.memory_artifact_id,
            memory_service=memory_service,
            cursors=self.repositories.cursors,
            repository=self.repositories.statistics,
            recurrence=self.repositories.recurrence,
            artifacts=self.repositories.artifacts,
            token_estimator=None if self.token_estimator is None else self.token_estimator.profile,
            model_usage=self.model_usage,
        )

    def recall_tokens(self) -> RelationalRecallTokenEstimator | None:
        if self.token_estimator is None:
            return None

        def memory_service(scope_id: str, connection: AsyncConnection) -> MemoryService:
            services = self if scope_id == self.scope_id else replace(self, scope_id=scope_id)
            _, source_catalog = services.sources(connection)
            return services.memory(source_catalog, connection)

        return RelationalRecallTokenEstimator(
            database=self.database,
            scope_id=self.scope_id,
            sources=self.repositories.sources,
            artifacts=self.repositories.artifacts,
            memory_service=memory_service,
            estimator=self.token_estimator,
        )


class RelationalContexts:
    """Compose typed, scope-bound contexts without owning the database lifecycle."""

    def __init__(
        self,
        *,
        database: AsyncDatabase,
        index: MemoryIndex | None = None,
        topic_memory_index: TopicMemoryIndex | None = None,
        experience_index: ExperienceIndex | None = None,
        candidate_pipeline: CandidatePipeline | None = None,
        experience_pipeline: ExperienceCandidatePipeline | None = None,
        experience_generator: ExperienceGenerator | None = None,
        skill_generator: SkillGenerator | None = None,
        external_skill_provider: ExternalSkillProvider | None = None,
        handoff_pipeline: HandoffGenerationPipeline | None = None,
        embedding_model: EmbeddingModel | None = None,
        token_estimator: TokenEstimator | None = None,
        memory_reranker: MemoryReranker | None = None,
        decision_model: DecisionModel | None = None,
        memory_write_gate: MemoryWriteGate | None = None,
        memory_rerank_candidate_limit: int = 30,
        memory_capacity_budget: MemoryCapacityBudget | None = None,
        memory_compaction: MemoryCompactionPolicy | None = None,
        memory_max_history_revisions: int = 100,
        id_factory: IdFactory | None = None,
        handoff_artifact_id: str = "handoff",
        memory_artifact_id: str = "memory",
        source_registry: SourceDefinitionRegistry | None = None,
        cursor_secret: bytes | None = None,
        tracing: RuntimeTracing | None = None,
        prompt_registry: PromptRegistry | None = None,
        prompt_demonstrators: dict[str, DemonstrationGenerator] | None = None,
        handoff_verification_keys: tuple[bytes, ...] = (),
        topic_memory_write_timeout_seconds: float = 30.0,
        topic_memory_write_concurrency: int = 4,
        model_usage_queue_capacity: int = 256,
        model_usage_write_timeout_seconds: float = 1.0,
        model_usage_flush_timeout_seconds: float = 0.5,
    ) -> None:
        self.database = database
        self.scopes = ScopeApplication(database, cursor_secret=cursor_secret)
        self.source_registry = source_registry or BUILTIN_SOURCE_REGISTRY
        self.index = NoMemoryIndex() if index is None else index
        self.topic_memory_index = NoTopicMemoryIndex() if topic_memory_index is None else topic_memory_index
        self.experience_index = NoExperienceIndex() if experience_index is None else experience_index
        source_repository = SourceRepository(self.source_registry)
        artifact_repository = ArtifactRepository(
            (Handoff, Memory, Experience, Skill, Profile, Prompt, TopicMemory),
            sources=source_repository,
        )
        topic_memory_repository = TopicMemoryRepository(artifacts=artifact_repository, index=self.topic_memory_index)
        self.repositories = _Repositories(
            sources=source_repository,
            artifacts=artifact_repository,
            governance=ArtifactGovernanceRepository(),
            candidates=CandidateRepository({
                Experience.family: ExperienceContent,
                Skill.family: SkillContent,
                Profile.family: ProfileCandidateProposal,
            }),
            connector_checkpoints=ConnectorCheckpointRepository(),
            source_definitions=SourceDefinitionManifestRepository(),
            cursors=SourceCursorRepository(),
            external_skills=ExternalSkillRepository(),
            skill_packages=SkillPackageRepository(),
            agent_skill_targets=RemoteAgentSkillTargetRepository(),
            skill_publications=SkillPublicationRepository(),
            statistics=StatisticsRepository(),
            recurrence=RecurrenceRepository(),
            processing_pending=ArtifactProcessingPendingRepository(),
            processing_leases=ArtifactProcessingLeaseRepository(),
            processing_binding_states=ArtifactProcessingBindingStateRepository(),
            topic_memories=topic_memory_repository,
        )
        self._model_usage = _ModelUsageRecorder(
            database,
            self.repositories.statistics,
            queue_capacity=model_usage_queue_capacity,
            write_timeout_seconds=model_usage_write_timeout_seconds,
            flush_timeout_seconds=model_usage_flush_timeout_seconds,
        )
        self._id_factory = _scoped_id_factory(memory_artifact_id, id_factory)
        self.prompt_registry = prompt_registry or PromptRegistry(
            builtin_prompt_definitions(),
            injected=frozenset(
                key
                for key, component in (
                    ("memory.extract", candidate_pipeline),
                    ("memory.rerank", memory_reranker),
                    ("experience.incubate", experience_pipeline),
                    ("experience.generate", experience_generator),
                    ("skill.generate", skill_generator),
                    ("handoff.generate", handoff_pipeline),
                )
                if component is not None
            ),
        )
        self.prompts = PromptService(self.prompt_registry, self._prompt_head, prompt_demonstrators)
        self._generation_receipts = HandoffGenerationReceipts(
            cursor_secret if cursor_secret is not None else secrets.token_bytes(32),
            verification_keys=handoff_verification_keys,
        )
        topic_memory_writer = TopicMemoryManagementWriter(
            topic_memory_repository,
            embedding_model,
            timeout_seconds=topic_memory_write_timeout_seconds,
            max_concurrency=topic_memory_write_concurrency,
            usage_reporter=self.model_usage_reporter,
        )
        family_writers = FamilyManagementWriterRegistry((
            topic_memory_writer,
            PromptManagementWriter(self.repositories.artifacts, self.prompt_registry),
            ProfileManagementWriter(self.repositories.artifacts),
            MemoryManagementWriter(
                capacity_budget=memory_capacity_budget,
                database=database,
                artifacts=self.repositories.artifacts,
                index=self.index,
                embedding_model=embedding_model,
                id_factory=self._id_factory,
            ),
            ExperienceManagementWriter(self.repositories.artifacts, self.experience_index),
            SkillManagementWriter(
                self.repositories.artifacts,
                self.experience_index,
                self.repositories.skill_packages,
            ),
            HandoffManagementWriter(
                database=database,
                artifacts=self.repositories.artifacts,
                sources=self.repositories.sources,
                memory_index=self.index,
                id_factory=self._id_factory,
                memory_artifact_id=memory_artifact_id,
                handoff_artifact_id=handoff_artifact_id,
            ),
        ))
        self.profiles = RelationalProfileService(
            database,
            self.repositories.sources,
            self.repositories.artifacts,
            self.repositories.candidates,
            id_factory=id_factory,
            prompt_service=self.prompts,
        )
        self.subject_sources = SubjectSourceService(database, self.repositories.sources)
        self.records = RelationalRecordService(
            database,
            self.repositories.sources,
            self.repositories.artifacts,
            family_writers,
            id_factory=id_factory,
            cursor_secret=cursor_secret,
            processing_pending=self.repositories.processing_pending,
            source_processing_bindings=(TOPIC_MEMORY_SOURCE_WINDOW_BINDING,),
            topic_memory_list_reader=TopicMemoryArtifactListReader(
                database=database,
                artifacts=artifact_repository,
                topics=topic_memory_repository,
            ),
        )
        self.publications = ArtifactPublicationApplication(
            database,
            self.repositories.artifacts,
            self.scopes,
            experience_index=self.experience_index,
            topic_memory_writer=topic_memory_writer,
        )
        self._candidate_pipeline = candidate_pipeline
        self.memory_extraction = candidate_pipeline is not None
        self._experience_pipeline = experience_pipeline
        self.experience_incubation = experience_pipeline is not None
        self._experience_generator = experience_generator
        self.experience_generation = experience_generator is not None
        self._skill_generator = skill_generator
        self.managed_skill_generation = skill_generator is not None
        self._external_skill_provider = external_skill_provider
        self.external_skill_registry = external_skill_provider is not None
        self._handoff_pipeline = handoff_pipeline
        self.handoff_generation = handoff_pipeline is not None
        self._embedding_model = embedding_model
        self._token_estimator = token_estimator
        self._memory_reranker = memory_reranker
        self._decision_model = decision_model
        self._memory_write_gate = memory_write_gate
        self._memory_rerank_candidate_limit = memory_rerank_candidate_limit
        self._memory_capacity_budget = (
            MemoryCapacityBudget() if memory_capacity_budget is None else memory_capacity_budget
        )
        self._memory_compaction = MemoryCompactionPolicy() if memory_compaction is None else memory_compaction
        self._memory_max_history_revisions = memory_max_history_revisions
        self._handoff_artifact_id = handoff_artifact_id
        self._memory_artifact_id = memory_artifact_id
        self._tracing = tracing
        self._contexts: dict[
            str,
            PowerContext[BuiltinSources, BuiltinArtifacts, BuiltinTriggers],
        ] = {}
        self._source_locks: dict[str, asyncio.Lock] = {}
        self._activation_locks: dict[str, asyncio.Lock] = {}
        self._experience_locks: dict[str, asyncio.Lock] = {}
        self._skill_publication_locks: dict[tuple[str, str, str], asyncio.Lock] = {}

    @property
    def token_estimator(self) -> TokenEstimator:
        """Return the deployment-fixed estimator used by internal processors."""

        if self._token_estimator is None:
            raise RuntimeError("Token estimator is unavailable")  # noqa: TRY003
        return self._token_estimator

    def evict(self, scope_id: str, /) -> None:
        """Discard inactive scope-local compositions and serialization locks."""

        scope = validate_scope_id(scope_id)
        self._contexts.pop(scope, None)
        self._source_locks.pop(scope, None)
        self._activation_locks.pop(scope, None)
        self._experience_locks.pop(scope, None)

    def review(self, scope_id: str, /) -> ReviewService:
        """Return Candidate and reviewed Artifact operations bound to one scope."""

        return self._services_for(scope_id).review()

    def dream(
        self,
        generator: DreamGenerator | None,
        *,
        budget: DreamBudget,
        max_pending_per_scope: int,
        authorize: DreamAuthorizer | None = None,
        authorization_context: AuthorizationContext = nullcontext,
        attest_candidate: CandidateAttester | None = None,
        operations: tuple[DreamOperation, ...] = (),
        processing: ScopeInvocation | None = None,
    ) -> DreamService:
        return DreamService(
            database=self.database,
            artifacts=self.repositories.artifacts,
            evidence=lambda scope_id, authorizer: self._services_for(scope_id).evidence(authorizer),
            review=lambda scope_id, connection: self._services_for(scope_id).review(connection),
            generator=generator,
            budget=budget,
            max_pending_per_scope=max_pending_per_scope,
            authorize=authorize,
            authorization_context=authorization_context,
            attest_candidate=attest_candidate,
            operations=operations,
            processing=processing,
        )

    def generation(self, scope_id: str, /) -> ReviewedGenerationService:
        """Return model-backed reviewed generation bound to one scope."""

        return self._services_for(scope_id).generation()

    def statistics(self, scope_id: str, /) -> RelationalScopedStatistics:
        """Return product statistics bound to one scope."""

        return self._services_for(scope_id).statistics()

    def model_usage_reporter(
        self, scope_id: str, /
    ) -> Callable[[ModelUsagePurpose, ModelUsageOperation, InferenceUsage], Awaitable[None]]:
        """Return a best-effort usage callback for one operational Scope.

        The callback only freezes and enqueues the record. The runtime-owned
        recorder performs the independent short write; it never joins the
        caller's transaction and never consumes the caller's model deadline.
        """

        async def report(
            purpose: ModelUsagePurpose,
            operation: ModelUsageOperation,
            usage: InferenceUsage,
        ) -> None:
            self._model_usage.offer(scope_id, purpose, operation, usage, datetime.now(UTC).date())

        return report

    async def aclose_usage_recorder(self) -> None:
        """Drain the usage recorder after its producers and before the database.

        Ordering is load-bearing: closing the database first would reject the
        recorder's own write, and closing this before producers stop would drop
        records that were already accepted.
        """

        await self._model_usage.close()

    async def flush_model_usage(self) -> None:
        """Make usage accepted so far visible at an operation's completion boundary.

        The wait is bounded and covers only the records already accepted, so a
        continuously producing runtime cannot stall a completing operation.
        """

        await self._model_usage.flush()

    async def register_source_definition(
        self,
        manifest: SourceDefinitionManifest,
        /,
    ) -> SourceDefinitionManifest:
        """Register one immutable declarative Definition supplied by a worker."""

        _validate_source_definition_manifest(manifest, self.source_registry)
        try:
            async with self.database.transaction() as connection:
                stored = await self.repositories.source_definitions.register(connection, manifest)
        except StoredPayloadConflictError as error:
            raise SourceConflictError("definition-manifest", error.identity) from None
        return stored

    async def connector_checkpoint(self, binding: ConnectorBinding, /) -> ConnectorCheckpointState:
        """Read the checkpoint owned by one remote Connector binding."""

        async with self.database.transaction() as connection:
            checkpoint = await self.repositories.connector_checkpoints.load(connection, binding)
        return ConnectorCheckpointState(binding=binding, checkpoint=checkpoint)

    async def submit_source_observation(
        self,
        request: SubmitSourceObservation,
        /,
    ) -> SourceReceipt:
        """Validate and durably append one worker-materialized Source observation."""

        observation = request.observation
        try:
            async with self.database.transaction() as connection:
                manifest = await self.repositories.source_definitions.get(
                    connection,
                    observation.source_type,
                    observation.definition_version,
                )
        except RepositoryNotFoundError:
            raise SourceDefinitionNotFoundError(observation.source_type, observation.definition_version) from None
        _validate_source_observation(observation, manifest)
        services = self._services_for(request.scope_id)
        source_store, source_catalog = services.sources()
        stored = await source_store.add(observation)
        return SourceReceipt(
            source_ref=source_catalog.as_ref(stored),
            sequence=await source_store.position(stored),
        )

    async def commit_connector_checkpoint(
        self,
        request: CommitConnectorCheckpoint,
        /,
    ) -> ConnectorCheckpointState:
        """Commit one worker checkpoint only when its starting value still matches."""

        async with self.database.transaction() as connection:
            await self.repositories.connector_checkpoints.save(
                connection,
                request.binding,
                request.checkpoint,
                expected=request.expected,
            )
        return ConnectorCheckpointState(binding=request.binding, checkpoint=request.checkpoint)

    async def estimate_recall_tokens(
        self,
        scope_id: str,
        build: PreparedContextBuild,
        /,
    ) -> RecallTokenMeasurement | None:
        estimator = self._services_for(scope_id).recall_tokens()
        return None if estimator is None else await estimator.estimate(build)

    async def _prompt_head(self, scope_id: str, key: str) -> Prompt | None:
        async with self.database.connection() as connection:
            try:
                return cast(Prompt, await self.repositories.artifacts.latest(connection, scope_id, "prompt", key))
            except RepositoryNotFoundError:
                return None

    async def search_experience(
        self,
        scope_id: str,
        query: str,
        limit: int,
        /,
    ) -> tuple[ExperienceSearchHit, ...]:
        """Recall relevant approved Experience heads in one scope."""

        return (await self.search_experience_outcome(scope_id, query, limit)).hits

    async def search_experience_outcome(
        self,
        scope_id: str,
        query: str,
        limit: int,
        /,
        *,
        admission: AdmissionFloor | None = None,
    ) -> ExperienceSearchOutcome:
        """Recall Experience heads and include internal admission accounting.

        The outcome carries the admission counts alongside the hits so the recall gate can
        report retrieved-versus-admitted without a second pass.
        """

        if limit < 1:
            raise ValueError("Experience search limit must be positive")  # noqa: TRY003
        scope = validate_scope_id(scope_id)
        async with self.database.transaction() as connection:
            return await self.experience_index.search(connection, scope, query, limit, admission=admission)

    async def get_topic_memory(
        self,
        scope_id: str,
        artifact_ref: ArtifactRef,
        /,
    ) -> PublishedTopicMemory:
        """Return one exact published Topic Revision in a single scope."""

        scope = validate_scope_id(scope_id)
        async with self.database.transaction() as connection:
            try:
                return await self.repositories.topic_memories.get_exact(connection, scope, artifact_ref)
            except RepositoryNotFoundError as error:
                raise ArtifactNotFoundError(artifact_ref) from error

    async def request_topic_memory_flush(self, scope_id: str, /) -> bool:
        """Persist one flush generation and return only after its transaction commits."""

        scope = validate_scope_id(scope_id)
        async with self.database.transaction() as connection:
            pending = await self.repositories.processing_pending.request_flush(
                connection,
                scope,
                TOPIC_MEMORY_SOURCE_WINDOW_BINDING,
            )
            if pending is not None:
                await ArtifactProcessingIntentRepository().request(
                    connection, scope, TOPIC_MEMORY_SOURCE_WINDOW_BINDING
                )
        return pending is not None

    async def browse_topic_memories(
        self,
        scope_id: str,
        /,
        *,
        limit: int,
        after: TopicMemoryBrowseCursor | None = None,
    ) -> tuple[TopicMemoryCurrentItem, ...]:
        """Browse only current complete Topic heads with a stable keyset boundary."""

        scope = validate_scope_id(scope_id)
        async with self.database.transaction() as connection:
            return await self.repositories.topic_memories.browse_current(
                connection,
                scope,
                limit=limit,
                after=after,
            )

    async def search_topic_memories(
        self,
        scope_id: str,
        query: str,
        /,
        *,
        limit: int,
        mode: TopicMemorySearchMode = "auto",
        query_vector: tuple[float, ...] | None = None,
        embedding_profile: EmbeddingProfile | None = None,
        admission: AdmissionFloor | None = None,
        query_embedding: MemoryQueryEmbedding | None = None,
    ) -> TopicMemorySearchResult:
        """Search current active Topic projections in this deployment."""

        if query_embedding is not None:
            query_vector = query_embedding.query_vector
            embedding_profile = query_embedding.embedding_profile
        scope = validate_scope_id(scope_id)
        async with self.database.transaction() as connection:
            return await self.repositories.topic_memories.search(
                connection,
                scope,
                query,
                limit=limit,
                mode=mode,
                query_vector=query_vector,
                embedding_profile=embedding_profile,
                admission=admission,
            )

    async def search_skills(
        self,
        scope_id: str,
        query: str,
        limit: int,
        /,
    ) -> tuple[SkillSearchHit, ...]:
        """Recall relevant active managed Skill heads in one scope."""

        if limit < 1:
            raise ValueError("Skill search limit must be positive")  # noqa: TRY003
        scope = validate_scope_id(scope_id)
        async with self.database.transaction() as connection:
            return await self.experience_index.search_skills(connection, scope, query, limit)

    async def get_skill_governance(
        self,
        scope_id: str,
        artifact_id: str,
        /,
    ) -> ArtifactGovernance:
        scope = validate_scope_id(scope_id)
        async with self.database.transaction() as connection:
            return await self.repositories.governance.get(connection, scope, Skill.family, artifact_id)

    async def get_skill_origins(self, scope_id: str, skills: tuple[Skill, ...], /) -> tuple[SkillOrigin, ...]:
        """Project exact external takeover evidence through later Skill revisions."""

        scope = validate_scope_id(scope_id)
        async with self.database.transaction() as connection:
            origins: list[SkillOrigin] = []
            for skill in skills:
                origins.append(
                    await self._skill_origin(
                        connection,
                        scope,
                        skill,
                        visited={_artifact_identity(skill.as_ref())},
                    )
                )
            return tuple(origins)

    async def _skill_origin(
        self,
        connection: AsyncConnection,
        scope_id: str,
        skill: Skill,
        *,
        visited: set[tuple[str, str, int]],
    ) -> SkillOrigin:
        for source_ref in skill.lineage.sources:
            if source_ref.source_type != EXTERNAL_SKILL_SNAPSHOT_SOURCE_ADAPTER.name:
                continue
            stored = await self.repositories.sources.get(connection, scope_id, source_ref)
            if isinstance(stored.value, ExternalSkillSnapshotSource):
                kind = (
                    SkillOriginKind.EXTERNAL_IMPORT
                    if stored.value.mode is ExternalSkillImportMode.IMPORT
                    else SkillOriginKind.EXTERNAL_FORK
                )
                return SkillOrigin(kind=kind, registration=stored.value.snapshot.registration, source=source_ref)

        for artifact_ref in skill.lineage.artifacts:
            identity = _artifact_identity(artifact_ref)
            if artifact_ref.family != Skill.family or identity in visited:
                continue
            visited.add(identity)
            upstream = await self.repositories.artifacts.get(connection, scope_id, artifact_ref)
            if isinstance(upstream, Skill):
                origin = await self._skill_origin(connection, scope_id, upstream, visited=visited)
                if origin.kind is not SkillOriginKind.POWERCONTEXT:
                    return origin
        return SkillOrigin(kind=SkillOriginKind.POWERCONTEXT)

    async def list_skills(
        self,
        scope_id: str,
        include_deprecated: bool,
        limit: int,
        /,
    ) -> tuple[tuple[Skill, ArtifactGovernance], ...]:
        """List current managed Skill heads with mutable governance state."""

        if limit < 1:
            raise ValueError("Skill Library limit must be positive")  # noqa: TRY003
        scope = validate_scope_id(scope_id)
        states = (
            (ArtifactLifecycleState.ACTIVE.value, ArtifactLifecycleState.DEPRECATED.value)
            if include_deprecated
            else (ArtifactLifecycleState.ACTIVE.value,)
        )
        async with self.database.transaction() as connection:
            rows = tuple(
                (
                    await connection.execute(
                        select(
                            ARTIFACT_HEADS_TABLE.c.artifact_id,
                            ARTIFACT_HEADS_TABLE.c.revision,
                        )
                        .where(
                            ARTIFACT_HEADS_TABLE.c.scope_id == scope,
                            ARTIFACT_HEADS_TABLE.c.family == Skill.family,
                            ARTIFACT_HEADS_TABLE.c.lifecycle_state.in_(states),
                        )
                        .order_by(ARTIFACT_HEADS_TABLE.c.artifact_id)
                        .limit(limit)
                    )
                ).mappings()
            )
            values = []
            for row in rows:
                artifact_id = str(row["artifact_id"])
                skill = await self.repositories.artifacts.get(
                    connection,
                    scope,
                    ArtifactRef(
                        family=Skill.family,
                        artifact_id=artifact_id,
                        revision=int(row["revision"]),
                    ),
                )
                governance = await self.repositories.governance.get(connection, scope, Skill.family, artifact_id)
                values.append((cast(Skill, skill), governance))
            return tuple(values)

    async def update_skill_lifecycle(
        self,
        scope_id: str,
        artifact_id: str,
        expected_generation: int,
        lifecycle_state: ArtifactLifecycleState,
        replacement_artifact_id: str | None,
        /,
    ) -> ArtifactGovernance:
        scope = validate_scope_id(scope_id)
        async with self.database.transaction() as connection:
            return await self.repositories.governance.transition(
                connection,
                scope,
                Skill.family,
                artifact_id,
                expected_generation,
                lifecycle_state,
                replacement_artifact_id,
            )

    async def skill_package(
        self,
        scope_id: str,
        artifact: ArtifactRef,
        /,
    ) -> SkillPackageSnapshot:
        """Resolve and verify the exact package owned by an approved Skill Revision."""

        scope = validate_scope_id(scope_id)
        async with self.database.transaction() as connection:
            value = await self.repositories.artifacts.get(connection, scope, artifact)
            if not isinstance(value, Skill) or value.content.package is None:
                raise ValueError("the Skill Revision is not package-backed")  # noqa: TRY003
            return await self.repositories.skill_packages.get(connection, scope, value.content.package)

    async def package_snapshot(
        self,
        scope_id: str,
        package: SkillPackageRef,
        /,
    ) -> SkillPackageSnapshot:
        """Resolve one exact package reference for inert Review inspection."""

        scope = validate_scope_id(scope_id)
        async with self.database.transaction() as connection:
            return await self.repositories.skill_packages.get(connection, scope, package)

    async def upload_skill_package(
        self,
        scope_id: str,
        archive_bytes: bytes,
        reason: str | None,
        target: ArtifactRef | None,
        /,
    ) -> ArtifactCandidate[SkillContent]:
        """Canonicalize an explicit upload and create a pending exact-import Candidate."""

        scope = validate_scope_id(scope_id)
        package = await asyncio.to_thread(capture_skill_archive, archive_bytes)
        source = await SKILL_PACKAGE_UPLOAD_SOURCE_ADAPTER.resolve(
            SkillPackageUploadCapture(
                package=package.reference,
                name=package.metadata.name,
                description=package.metadata.description,
            )
        )
        async with self.database.transaction() as connection:
            await self.repositories.skill_packages.add(connection, scope, package)
            stored = await self.repositories.sources.add(connection, scope, source)
            artifacts = () if target is None else (target,)
            return (
                await self
                ._services_for(scope)
                .review(connection)
                .propose_skill(
                    package.as_skill_content(),
                    sources=(stored.ref,),
                    artifacts=artifacts,
                    target=target,
                    reason=reason,
                )
            )

    async def record_skill_usage(
        self,
        scope_id: str,
        observation: SkillUsageCapture,
        /,
    ) -> SourceReceipt:
        """Validate and capture one exact, bounded Skill usage observation."""

        scope = validate_scope_id(scope_id)
        source = await SKILL_USAGE_SOURCE_ADAPTER.resolve(observation)
        async with self.database.transaction() as connection:
            value = await self.repositories.artifacts.get(connection, scope, observation.skill_ref)
            if not isinstance(value, Skill) or value.content.package is None:
                raise ValueError("usage must reference a package-backed Skill Revision")  # noqa: TRY003
            expected_digest = f"sha256:{value.content.package.tree_digest}"
            if observation.package_digest != expected_digest:
                raise ValueError("usage package digest does not match the Skill Revision")  # noqa: TRY003
            if observation.task_source is not None:
                await self.repositories.sources.get(connection, scope, observation.task_source)
            stored = await self.repositories.sources.add(connection, scope, source)
            return SourceReceipt(source_ref=stored.ref, sequence=stored.journal_position)

    def external_skills(self, scope_id: str, /) -> ExternalSkillRegistryService:
        """Return the host-local external Skill Registry bound to one scope."""

        if self._external_skill_provider is None:
            raise ExternalSkillRegistryUnavailableError
        return ExternalSkillRegistryService(
            database=self.database,
            scope_id=validate_scope_id(scope_id),
            repository=self.repositories.external_skills,
            provider=self._external_skill_provider,
        )

    def skill_publications(
        self,
        scope_id: str,
        target_id: str,
        artifact_id: str,
        /,
    ) -> ManagedSkillPublicationService:
        """Return safe package publication operations serialized for one target binding."""

        scope = validate_scope_id(scope_id)
        return ManagedSkillPublicationService(
            database=self.database,
            scope_id=scope,
            artifacts=self.repositories.artifacts,
            governance=self.repositories.governance,
            packages=self.repositories.skill_packages,
            publications=self.repositories.skill_publications,
            lock=self._skill_publication_locks.setdefault((scope, target_id, artifact_id), asyncio.Lock()),
        )

    def remote_skill_distribution(self) -> RemoteSkillDistributionService:
        """Return credential-bound remote target desired-state operations."""

        return RemoteSkillDistributionService(
            database=self.database,
            targets=self.repositories.agent_skill_targets,
            artifacts=self.repositories.artifacts,
            governance=self.repositories.governance,
            packages=self.repositories.skill_packages,
            publications=self.repositories.skill_publications,
        )

    async def import_external_skill(
        self,
        scope_id: str,
        external_skill_id: str,
        fingerprint: str,
        mode: ExternalSkillImportMode,
        reason: str | None,
        /,
    ) -> GeneratedCandidateResult:
        """Snapshot an exact package, preserving import bytes or using LLM only for a fork."""

        if mode is ExternalSkillImportMode.FORK and self._skill_generator is None:
            raise GenerationCapabilityUnavailableError(Skill.family)
        scope = validate_scope_id(scope_id)
        capture = await self.external_skills(scope).snapshot(external_skill_id, fingerprint)
        source = await EXTERNAL_SKILL_SNAPSHOT_SOURCE_ADAPTER.resolve(
            ExternalSkillSnapshotCapture(snapshot=capture.as_source_snapshot(), mode=mode)
        )
        async with self.database.transaction() as connection:
            await self.repositories.skill_packages.add(connection, scope, capture.package)
            stored, created = await self.repositories.sources.add_with_status(connection, scope, source)
            if created:
                await self.repositories.processing_pending.raise_source(
                    connection,
                    scope,
                    TOPIC_MEMORY_SOURCE_WINDOW_BINDING,
                    stored.journal_position,
                )
            if mode is ExternalSkillImportMode.IMPORT:
                candidate = (
                    await self
                    ._services_for(scope)
                    .review(connection)
                    .propose_skill(
                        capture.package.as_skill_content(),
                        sources=(stored.ref,),
                        artifacts=(),
                        target=None,
                        reason=reason,
                    )
                )
                return GeneratedCandidateResult(candidate=candidate)
        return await self.generation(scope).skill(
            origin=SkillGenerationOrigin.SOURCE,
            sources=(stored.ref,),
            artifacts=(),
            target=None,
            reason=reason,
        )

    async def scope_ids(self) -> tuple[str, ...]:
        """Return scopes with a Source journal, in deterministic order."""

        async with self.database.transaction() as connection:
            values = (
                await connection.execute(
                    select(SOURCE_JOURNAL_HEADS_TABLE.c.scope_id).order_by(SOURCE_JOURNAL_HEADS_TABLE.c.scope_id)
                )
            ).scalars()
            return tuple(str(value) for value in values)

    async def handoff_scope_ids(self) -> tuple[str, ...]:
        """Return scopes with a committed Handoff head, in deterministic order."""

        async with self.database.transaction() as connection:
            values = (
                await connection.execute(
                    select(ARTIFACT_HEADS_TABLE.c.scope_id)
                    .where(ARTIFACT_HEADS_TABLE.c.family == Handoff.family)
                    .distinct()
                    .order_by(ARTIFACT_HEADS_TABLE.c.scope_id)
                )
            ).scalars()
            return tuple(str(value) for value in values)

    async def process_memory(
        self,
        scope_id: str,
        limit: int,
        /,
        *,
        processing: ScopeInvocation | None = None,
        authorize_snapshot: MemorySnapshotAuthorizer | None = None,
        on_commit: MemoryCommitHook | None = None,
    ) -> MemoryFlushResult:
        services = self._services_for(scope_id)
        return await _RelationalTriggers(
            services=services,
            lock=self._activation_locks.setdefault(services.scope_id, asyncio.Lock()),
            tracing=self._tracing,
        ).flush(limit=limit, processing=processing, authorize_snapshot=authorize_snapshot, on_commit=on_commit)

    async def incubate_experience(
        self,
        scope_id: str,
        limit: int,
        /,
        *,
        processing: ScopeInvocation | None = None,
        on_commit: ExperienceCommitHook | None = None,
    ) -> ExperienceIncubationResult:
        """Process one independent Task Outcome Source window for Review."""

        services = self._services_for(scope_id)
        if services.experience_pipeline is None:
            raise RuntimeError("Experience incubation pipeline is not configured")  # noqa: TRY003
        return await _RelationalExperienceIncubator(
            services=services,
            lock=self._experience_locks.setdefault(services.scope_id, asyncio.Lock()),
        ).flush(limit=limit, processing=processing, on_commit=on_commit)

    async def get(
        self,
        scope_id: str,
        /,
    ) -> PowerContext[BuiltinSources, BuiltinArtifacts, BuiltinTriggers]:
        scope = validate_scope_id(scope_id)
        existing = self._contexts.get(scope)
        if existing is not None:
            return existing

        services = self._services_for(scope)
        sources_backend, source_catalog = services.sources()
        triggers: BuiltinTriggers = _RelationalTriggers(
            services=services,
            lock=self._activation_locks.setdefault(scope, asyncio.Lock()),
            tracing=self._tracing,
        )
        context: PowerContext[BuiltinSources, BuiltinArtifacts, BuiltinTriggers] = PowerContext(
            sources=BuiltinSources(
                catalog=source_catalog,
                store=sources_backend,
                journal=sources_backend,
            ),
            artifacts=BuiltinArtifacts(
                handoff=services.handoff(source_catalog),
                handoff_artifact_id=self._handoff_artifact_id,
                memory=services.memory(source_catalog),
                memory_artifact_id=self._memory_artifact_id,
            ),
            triggers=triggers,
        )
        return self._contexts.setdefault(scope, context)

    def _services_for(self, scope_id: str) -> _ScopedServices:
        scope = validate_scope_id(scope_id)
        return _ScopedServices(
            database=self.database,
            scope_id=scope,
            repositories=self.repositories,
            index=self.index,
            experience_index=self.experience_index,
            candidate_pipeline=self._candidate_pipeline,
            experience_pipeline=self._experience_pipeline,
            experience_generator=self._experience_generator,
            skill_generator=self._skill_generator,
            handoff_pipeline=self._handoff_pipeline,
            embedding_model=self._embedding_model,
            memory_reranker=self._memory_reranker,
            memory_rerank_candidate_limit=self._memory_rerank_candidate_limit,
            decision_model=self._decision_model,
            memory_write_gate=self._memory_write_gate,
            memory_capacity_budget=self._memory_capacity_budget,
            memory_compaction=self._memory_compaction,
            memory_max_history_revisions=self._memory_max_history_revisions,
            id_factory=self._id_factory,
            handoff_artifact_id=self._handoff_artifact_id,
            memory_artifact_id=self._memory_artifact_id,
            source_lock=self._source_locks.setdefault(scope, asyncio.Lock()),
            prompts=self.prompts,
            generation_receipts=self._generation_receipts,
            token_estimator=self._token_estimator,
            source_registry=self.source_registry,
            model_usage=self._model_usage,
        )


class _RelationalMemorySourceResolver:
    """Admit Memory evidence without changing the ordinary Source catalog."""

    def __init__(
        self,
        *,
        database: AsyncDatabase,
        scope_id: str,
        catalog: SourceCatalog,
        access: GenerationSourceAccess,
        connection: AsyncConnection | None = None,
    ) -> None:
        self._database = database
        self._scope_id = scope_id
        self._catalog = catalog
        self._access = access
        self._connection = connection

    def as_ref(self, source: Source, /) -> SourceRef:
        return self._catalog.as_ref(source)

    def project(self, source: Source, key: SourceProjectionKey, /) -> object:
        return self._catalog.project(source, key)

    async def get_ref(self, ref: SourceRef, /) -> Source:
        try:
            async with self._database.connection(self._connection) as connection:
                (stored,) = await self._access.require_for_generation(connection, self._scope_id, (ref,))
        except RepositoryNotFoundError:
            raise SourceNotFoundError(ref) from None
        return stored.value

    async def get(self, source: Source, /) -> Source:
        try:
            async with self._database.connection(self._connection) as connection:
                (stored,) = await self._access.require_for_generation(
                    connection, self._scope_id, (self.as_ref(source),)
                )
        except RepositoryNotFoundError:
            raise SourceNotFoundError(source) from None
        if type(stored.value) is not type(source) or stored.value != source:
            raise SourceNotFoundError(source)
        return stored.value


class _RelationalSources:
    def __init__(
        self,
        *,
        database: AsyncDatabase,
        scope_id: str,
        registry: SourceDefinitionRegistry,
        repository: SourceRepository,
        processing_pending: ArtifactProcessingPendingRepository,
        write_lock: asyncio.Lock,
        connection: AsyncConnection | None = None,
    ) -> None:
        self._database = database
        self._scope_id = scope_id
        self._registry = registry
        self._repository = repository
        self._processing_pending = processing_pending
        self._write_lock = write_lock
        self._bound_connection = connection

    async def add(self, source: Source, /) -> Source:
        async with self._write_lock:
            try:
                async with self._database.connection(self._bound_connection) as connection:
                    stored, created = await self._repository.add_with_status(connection, self._scope_id, source)
                    if created:
                        await self._processing_pending.raise_source(
                            connection,
                            self._scope_id,
                            TOPIC_MEMORY_SOURCE_WINDOW_BINDING,
                            stored.journal_position,
                        )
                    return stored.value
            except StoredPayloadConflictError as error:
                raise SourceConflictError("identity", error.identity) from None

    async def get(self, source: Source, /) -> Source:
        ref = self._as_ref(source)
        try:
            async with self._database.connection(self._bound_connection) as connection:
                return (await self._repository.get(connection, self._scope_id, ref)).value
        except RepositoryNotFoundError:
            raise SourceNotFoundError(source) from None

    async def list(self) -> tuple[Source, ...]:
        async with self._database.connection(self._bound_connection) as connection:
            rows = await self._repository.list(connection, self._scope_id)
        return tuple(row.value for row in rows)

    async def position(self, source: Source, /) -> int:
        ref = self._as_ref(source)
        try:
            async with self._database.connection(self._bound_connection) as connection:
                return (await self._repository.get(connection, self._scope_id, ref)).journal_position
        except RepositoryNotFoundError:
            raise SourceNotFoundError(source) from None

    async def entries(self) -> tuple[SourceJournalEntry, ...]:
        async with self._database.connection(self._bound_connection) as connection:
            rows = await self._repository.list(connection, self._scope_id)
        return tuple(
            SourceJournalEntry(
                source_ref=row.ref,
                source=row.value,
                position=row.journal_position,
            )
            for row in rows
        )

    def _as_ref(self, source: Source) -> SourceRef:
        if isinstance(source, SourceObservation):
            return SourceRef(source_type=source.source_type, source_id=source.name)
        definition = self._registry.definition_for_source(source)
        return SourceRef(source_type=definition.name, source_id=source.name)


class _RelationalArtifactResolver:
    def __init__(
        self,
        *,
        database: AsyncDatabase,
        scope_id: str,
        repository: ArtifactRepository,
        connection: AsyncConnection | None = None,
    ) -> None:
        self._database = database
        self._scope_id = scope_id
        self._repository = repository
        self._bound_connection = connection

    async def get(self, artifact: Artifact[object], /) -> Artifact[object]:
        try:
            return await self.get_ref(artifact.as_ref())
        except ArtifactNotFoundError:
            raise ArtifactNotFoundError(artifact) from None

    async def get_ref(self, ref: ArtifactRef, /) -> Artifact[object]:
        try:
            async with self._database.connection(self._bound_connection) as connection:
                return cast(Artifact[object], await self._repository.get(connection, self._scope_id, ref))
        except RepositoryNotFoundError:
            raise ArtifactNotFoundError(ref) from None


class _RelationalTriggers:
    def __init__(
        self,
        *,
        services: _ScopedServices,
        lock: asyncio.Lock,
        tracing: RuntimeTracing | None = None,
    ) -> None:
        self._services = services
        self._lock = lock
        self._tracing = tracing
        self._handoff_trigger = HandoffTrigger()
        self._prompt_context = ScopedPrompts(services.prompts, services.scope_id)
        self._trigger = SourceWindowTrigger()

    async def activate_handoff(self, request: ActivateHandoff, /) -> HandoffActivation:
        async with self._lock:
            async with self._services.database.transaction() as connection:
                try:
                    (source,) = await self._services.generation_sources().require_for_generation(
                        connection,
                        self._services.scope_id,
                        (request.boundary_source,),
                    )
                except RepositoryNotFoundError:
                    raise HandoffEvidenceUnavailableError(
                        HandoffSourceCitation(source_ref=request.boundary_source)
                    ) from None
                require_source_eligible(request.boundary_source, source.value)
                state_row = await self._services.repositories.cursors.load(
                    connection,
                    self._services.scope_id,
                    HANDOFF_BOUNDARY_TRIGGER_NAME,
                )
                state = self._handoff_trigger.initial_state() if state_row is None else state_row.cursor
                transition = self._handoff_trigger.activate(
                    HandoffBoundary(
                        position=source.journal_position,
                        activation=request,
                    ),
                    state,
                )
            if not transition.actions:
                return HandoffActivation(
                    status="ignored",
                    boundary_source=request.boundary_source,
                    previous_position=state.sequence,
                    current_position=state.sequence,
                    draft=None,
                )

            _, source_catalog = self._services.sources()
            draft = await self._services.handoff(source_catalog).prepare(transition.actions[0])
            async with self._services.database.transaction() as connection:
                await self._services.repositories.cursors.save(
                    connection,
                    self._services.scope_id,
                    HANDOFF_BOUNDARY_TRIGGER_NAME,
                    transition.state,
                    expected_generation=None if state_row is None else state_row.generation,
                )
            return HandoffActivation(
                status="generated",
                boundary_source=request.boundary_source,
                previous_position=state.sequence,
                current_position=transition.state.sequence,
                draft=draft,
            )

    async def cursor(self) -> SourceCursor:
        async with self._services.database.transaction() as connection:
            state = await self._services.repositories.cursors.load(
                connection,
                self._services.scope_id,
                SOURCE_WINDOW_TRIGGER_NAME,
            )
        return self._trigger.initial_state() if state is None else state.cursor

    @prompt_operation("memory.extract")
    async def flush(
        self,
        *,
        limit: int,
        processing: ScopeInvocation | None = None,
        authorize_snapshot: MemorySnapshotAuthorizer | None = None,
        on_commit: MemoryCommitHook | None = None,
    ) -> MemoryFlushResult:
        async with self._lock:
            async with self._services.database.transaction() as connection:
                if processing is not None:
                    await processing.start(connection)
                state_row = await self._services.repositories.cursors.load(
                    connection,
                    self._services.scope_id,
                    SOURCE_WINDOW_TRIGGER_NAME,
                )
                state = self._trigger.initial_state() if state_row is None else state_row.cursor
                high_watermark = await self._services.repositories.sources.journal_position(
                    connection,
                    self._services.scope_id,
                )
                signal = SourceHighWatermark(sequence=high_watermark, limit=limit)
                transition = self._trigger.activate(signal, state)
                sources = () if not transition.actions else await self._sources(connection, transition.actions[0])
                if not transition.actions and processing is not None:
                    await processing.complete(connection, remaining_work=False)
            if not transition.actions:
                return MemoryFlushResult(
                    previous_cursor=state.sequence,
                    high_watermark=high_watermark,
                    current_cursor=state.sequence,
                    source_count=0,
                    memory_ref=None,
                )

            action = transition.actions[0]
            prepared = (
                None if not sources else await self._prepare_memory(sources, authorize_snapshot=authorize_snapshot)
            )
            held = _is_held_write(prepared)
            commit = None if prepared is None else prepared.commit
            with self._stage(
                _MEMORY_COMMIT_STAGE,
                attributes={
                    _MEMORY_COMMIT_MEMORY_CHANGED: commit is not None,
                    _MEMORY_COMMIT_ENTRY_VERSION_COUNT: 0 if commit is None else len(commit.entry_versions),
                },
            ):
                async with self._services.database.transaction() as connection:
                    if processing is not None:
                        await processing.guard(connection)
                    updated = None
                    if prepared is not None:
                        _, source_catalog = self._services.sources(connection)
                        updated = await self._services.memory(source_catalog, connection).apply(prepared)
                    await self._services.repositories.cursors.save(
                        connection,
                        self._services.scope_id,
                        SOURCE_WINDOW_TRIGGER_NAME,
                        transition.state,
                        expected_generation=None if state_row is None else state_row.generation,
                    )
                    if on_commit is not None and prepared is not None:
                        before = prepared.result if prepared.commit is None else prepared.commit.base
                        await on_commit(connection, before, updated)
                    if processing is not None:
                        await processing.complete(connection, remaining_work=action.through < high_watermark)
            return MemoryFlushResult(
                previous_cursor=action.after,
                high_watermark=high_watermark,
                current_cursor=action.through,
                source_count=len(sources),
                memory_ref=None if updated is None else updated.as_ref(),
                held_count=1 if held else 0,
                hold_codes=_hold_codes(prepared),
            )

    async def _sources(
        self,
        connection: AsyncConnection,
        action: ProcessSourceWindow,
    ) -> tuple[Source, ...]:
        rows = await self._services.generation_sources().list_window_for_generation(
            connection,
            self._services.scope_id,
            after=action.after,
            through=action.through,
        )
        return tuple(
            row.value for row in rows if row.journal_position <= action.through and is_generation_eligible(row.value)
        )

    async def _prepare_memory(
        self, sources: tuple[Source, ...], *, authorize_snapshot: MemorySnapshotAuthorizer | None = None
    ) -> MemoryWritePlan:
        _, source_catalog = self._services.sources()
        service = self._services.memory(source_catalog)
        try:
            current = await service.head(self._services.memory_artifact_id)
        except ArtifactNotFoundError:
            current = None
        if authorize_snapshot is not None:
            await authorize_snapshot(current)
        return await service.plan_remember(memory=current, sources=sources, mode="extract")

    def _stage(
        self,
        name: str,
        *,
        attributes: Mapping[str, TraceAttribute],
    ) -> AbstractContextManager[RuntimeSpan | None]:
        """Open one optional Runtime tracing stage around relational work."""

        if self._tracing is None:
            return nullcontext(None)
        return self._tracing.stage(name, attributes=attributes)


class _RelationalExperienceIncubator:
    """Advance one independent Source cursor with atomic Candidate writes."""

    def __init__(
        self,
        *,
        services: _ScopedServices,
        lock: asyncio.Lock,
    ) -> None:
        self._services = services
        self._prompt_context = ScopedPrompts(services.prompts, services.scope_id)
        self._lock = lock
        self._trigger = SourceWindowTrigger()

    @prompt_operation("experience.incubate")
    async def flush(  # noqa: C901
        self,
        *,
        limit: int,
        processing: ScopeInvocation | None = None,
        on_commit: ExperienceCommitHook | None = None,
    ) -> ExperienceIncubationResult:
        async with self._lock:
            async with self._services.database.transaction() as connection:
                if processing is not None:
                    await processing.start(connection)
                state_row = await self._services.repositories.cursors.load(
                    connection,
                    self._services.scope_id,
                    EXPERIENCE_INCUBATION_CURSOR_NAME,
                )
                state = self._trigger.initial_state() if state_row is None else state_row.cursor
                high_watermark = await self._services.repositories.sources.journal_position(
                    connection,
                    self._services.scope_id,
                )
                transition = self._trigger.activate(
                    SourceHighWatermark(sequence=high_watermark, limit=limit),
                    state,
                )
                rows = () if not transition.actions else await self._sources(connection, transition.actions[0])
                if not transition.actions and processing is not None:
                    await processing.complete(connection, remaining_work=False)
            if not transition.actions:
                return ExperienceIncubationResult(
                    previous_cursor=state.sequence,
                    high_watermark=high_watermark,
                    current_cursor=state.sequence,
                    source_count=0,
                    candidate_count=0,
                )

            pipeline = self._services.experience_pipeline
            if pipeline is None:
                raise RuntimeError("Experience incubation pipeline is not configured")  # noqa: TRY003
            action = transition.actions[0]
            eligible_rows = tuple(row for row in rows if is_generation_eligible(row.value))
            if not eligible_rows:
                async with self._services.database.transaction() as connection:
                    if processing is not None:
                        await processing.guard(connection)
                    await self._services.repositories.cursors.save(
                        connection,
                        self._services.scope_id,
                        EXPERIENCE_INCUBATION_CURSOR_NAME,
                        transition.state,
                        expected_generation=None if state_row is None else state_row.generation,
                    )
                    if processing is not None:
                        await processing.complete(connection, remaining_work=action.through < high_watermark)
                return ExperienceIncubationResult(
                    previous_cursor=action.after,
                    high_watermark=high_watermark,
                    current_cursor=action.through,
                    source_count=0,
                    candidate_count=0,
                )
            plans = await pipeline.incubate(tuple(row.value for row in eligible_rows))
            selection = current_prompt("experience.incubate")
            prompt_refs = () if selection is None or selection.artifact is None else (selection.artifact,)
            _validate_experience_plans(plans, eligible_rows)
            candidate_ids: list[str] = []
            candidates: list[ArtifactCandidate[ExperienceContent]] = []
            async with self._services.database.transaction() as connection:
                if processing is not None:
                    await processing.guard(connection)
                review = self._services.review(connection)
                for plan in plans:
                    candidate = await review.propose_experience(
                        plan.proposal,
                        sources=plan.sources,
                        artifacts=prompt_refs,
                        target=None,
                        reason=plan.reason,
                    )
                    candidate_ids.append(candidate.candidate_id)
                    candidates.append(candidate)
                for proposal in await self._services.recurrence_ledger().record_window(connection, eligible_rows):
                    target_content = await self._services.repositories.artifacts.get(
                        connection,
                        self._services.scope_id,
                        proposal.target,
                    )
                    candidate = await review.propose_experience(
                        proposal.proposal,
                        sources=proposal.sources,
                        artifacts=(target_content.as_ref(),),
                        target=proposal.target,
                        reason=proposal.reason,
                    )
                    candidate_ids.append(candidate.candidate_id)
                    candidates.append(candidate)
                await self._services.repositories.cursors.save(
                    connection,
                    self._services.scope_id,
                    EXPERIENCE_INCUBATION_CURSOR_NAME,
                    transition.state,
                    expected_generation=None if state_row is None else state_row.generation,
                )
                if on_commit is not None:
                    await on_commit(connection, tuple(candidates))
                if processing is not None:
                    await processing.complete(connection, remaining_work=action.through < high_watermark)
            return ExperienceIncubationResult(
                previous_cursor=action.after,
                high_watermark=high_watermark,
                current_cursor=action.through,
                source_count=len(eligible_rows),
                candidate_count=len(candidate_ids),
                candidate_ids=tuple(candidate_ids),
            )

    async def _sources(
        self,
        connection: AsyncConnection,
        action: ProcessSourceWindow,
    ) -> tuple[StoredSource, ...]:
        return await self._services.generation_sources().list_window_for_generation(
            connection,
            self._services.scope_id,
            after=action.after,
            through=action.through,
        )


def _validate_experience_plans(
    plans: tuple[ExperienceCandidateInput, ...],
    rows: tuple[StoredSource, ...],
) -> None:
    available = {(row.ref.source_type, row.ref.source_id) for row in rows}
    if any((source.source_type, source.source_id) not in available for plan in plans for source in plan.sources):
        raise InvalidInferenceOutputError(
            "experience-incubate",
            "pipeline cited a Source outside the current incubation window",
        )


def _validate_source_definition_manifest(
    manifest: SourceDefinitionManifest,
    source_registry: SourceDefinitionRegistry,
) -> None:
    if len(manifest.model_dump_json(by_alias=True).encode()) > 64 * 1024:
        raise InvalidSourceDefinitionError(type(manifest), "manifest", "must not exceed 64 KiB")
    try:
        source_registry.definition_for_name(manifest.name)
    except SourceDefinitionNotFoundError:
        pass
    else:
        raise InvalidSourceDefinitionError(type(manifest), "name", "must not replace an active Source Definition")
    _json_schema_validator(manifest.name, manifest.source_schema)
    standard_text_schema = TextEvidence.model_json_schema()
    for projection in manifest.projections:
        _json_schema_validator(projection.key.name, projection.schema_)
        if projection.key == TEXT_EVIDENCE_PROJECTION_KEY and projection.schema_ != standard_text_schema:
            raise InvalidSourceDefinitionError(
                type(manifest),
                "projection",
                f"{projection.key.name!r} must use the standard schema",
            )


def _validate_source_observation(source: SourceObservation, manifest: SourceDefinitionManifest) -> None:
    if source.source_type != manifest.name or source.definition_version != manifest.version:
        raise InvalidSourceObservationError("definition", "does not match the registered manifest identity")
    if source.definition_fingerprint != manifest.fingerprint:
        raise InvalidSourceObservationError("fingerprint", "does not match the registered manifest")
    if len(source.model_dump_json().encode()) > MAX_SOURCE_OBSERVATION_BYTES:
        raise InvalidSourceObservationError("size", "must not exceed 4 MiB")
    _validate_schema_value(manifest.name, manifest.source_schema, source.payload)

    declarations = {projection.key: projection for projection in manifest.projections}
    supplied = {projection.key: projection.value for projection in source.projections}
    if declarations.keys() != supplied.keys():
        raise InvalidSourceObservationError("projections", "must exactly match the registered manifest")
    for key, declaration in declarations.items():
        value = supplied[key]
        _validate_schema_value(key.name, declaration.schema_, value)
        if key == TEXT_EVIDENCE_PROJECTION_KEY:
            evidence = TextEvidence.model_validate(value)
            if evidence.source_type != source.source_type or evidence.source_id != source.name:
                raise InvalidSourceObservationError(
                    "text-evidence",
                    "source identity does not match the observation envelope",
                )


def _json_schema_validator(name: str, schema: Mapping[str, Any]) -> Validator:
    try:
        Draft202012Validator.check_schema(schema)
        return Draft202012Validator(schema, registry=Registry())
    except SchemaError as error:
        raise InvalidSourceDefinitionError(type(schema), "schema", f"{name!r} is not valid JSON Schema") from error


def _validate_schema_value(name: str, schema: Mapping[str, Any], value: object) -> None:
    try:
        _json_schema_validator(name, schema).validate(value)
    except (JsonSchemaValidationError, Unresolvable) as error:
        raise InvalidSourceObservationError("schema", f"value does not match {name!r}") from error


def _is_held_write(plan: MemoryWritePlan | None) -> bool:
    """Report whether the gate refused this prepared write."""

    if plan is None:
        return False
    decision = plan.decision
    return decision is not None and decision.verdict is MemoryWriteVerdict.HOLD


def _hold_codes(plan: MemoryWritePlan | None) -> tuple[str, ...]:
    """Expose the structured refusal code of a held write to the window caller."""

    if not _is_held_write(plan) or plan is None:
        return ()
    decision = plan.decision
    if decision is None or decision.code is None:
        return ()
    return (decision.code.value,)


def _scoped_id_factory(memory_artifact_id: str, delegate: IdFactory | None) -> IdFactory:
    def new_id(kind: str) -> str:
        if kind == "memory":
            return memory_artifact_id
        if delegate is not None:
            return delegate(kind)
        prefixes = {
            "candidate": "cand",
            "entry": "mem_ent",
            "experience": "exp",
            "skill": "skill",
            "version": "mem_ver",
        }
        return f"{prefixes[kind]}_{uuid4().hex}"

    return new_id
