# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""SQLite Memory search indexes using FTS5 and sqlite-vec."""

from __future__ import annotations

import json
import struct
from collections.abc import Mapping
from re import search
from typing import Any

from sqlalchemy import (
    CheckConstraint,
    Column,
    ForeignKeyConstraint,
    Integer,
    Table,
    UniqueConstraint,
    bindparam,
    delete,
    func,
    insert,
    select,
    text,
)
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncConnection

from powercontext.artifacts import ArtifactRef
from powercontext.builtin.artifacts.memory import (
    CapabilityNotSupportedError,
    EmbeddingProfile,
    MemoryCapabilities,
    MemoryProjection,
    MemorySearchChannels,
    MemorySearchRequest,
)
from powercontext.builtin.artifacts.memory.canonical import (
    embedding_content_hash,
    validate_embedding,
)
from powercontext.builtin.artifacts.search import fts_match_query
from powercontext.builtin.persistence.memory_index import memory_channel_hits
from powercontext.builtin.persistence.tables import (
    MAX_MEMORY_ENTRY_ID_LENGTH,
    MAX_MEMORY_HASH_LENGTH,
    MEMORY_ENTRY_HEADS_TABLE,
    SHARED_METADATA,
    identity_string,
)
from powercontext.builtin.persistence.tags import memory_tag_parameters, memory_tag_sql
from powercontext.limits import MAX_ARTIFACT_ID_LENGTH, MAX_SCOPE_ID_LENGTH

SQLITE_MEMORY_FTS_MARKER_TABLE = Table(
    "pc_memory_fts_index",
    SHARED_METADATA,
    Column("singleton", Integer, primary_key=True),
    Column("schema_version", Integer, nullable=False),
    CheckConstraint("singleton = 1", name="ck_pc_memory_fts_index_singleton"),
)


SQLITE_MEMORY_FTS_TABLES = (SQLITE_MEMORY_FTS_MARKER_TABLE,)


SQLITE_MEMORY_VECTOR_ENTRIES_TABLE = Table(
    "pc_memory_vector_entries",
    SHARED_METADATA,
    Column("vector_id", Integer, primary_key=True, autoincrement=True),
    Column("scope_id", identity_string(MAX_SCOPE_ID_LENGTH), nullable=False),
    Column("memory_artifact_id", identity_string(MAX_ARTIFACT_ID_LENGTH), nullable=False),
    Column("head_revision", Integer, nullable=False),
    Column("entry_id", identity_string(MAX_MEMORY_ENTRY_ID_LENGTH), nullable=False),
    Column("entry_version_id", identity_string(MAX_MEMORY_ENTRY_ID_LENGTH), nullable=False),
    Column("entry_content_hash", identity_string(MAX_MEMORY_HASH_LENGTH), nullable=False),
    Column("embedding_content_hash", identity_string(MAX_MEMORY_HASH_LENGTH), nullable=False),
    UniqueConstraint(
        "scope_id",
        "memory_artifact_id",
        "entry_id",
        name="uq_pc_memory_vector_entries_head",
    ),
    ForeignKeyConstraint(
        ("scope_id", "memory_artifact_id", "entry_id"),
        (
            "pc_memory_entry_heads.scope_id",
            "pc_memory_entry_heads.memory_artifact_id",
            "pc_memory_entry_heads.entry_id",
        ),
        ondelete="CASCADE",
    ),
    CheckConstraint("head_revision > 0", name="ck_pc_memory_vector_entries_revision_positive"),
    sqlite_autoincrement=True,
)


SQLITE_MEMORY_VECTOR_TABLES = (SQLITE_MEMORY_VECTOR_ENTRIES_TABLE,)


_FTS_TABLE_NAME = "pc_memory_entry_fts"
_CREATE_FTS_SQL = """
CREATE VIRTUAL TABLE IF NOT EXISTS pc_memory_entry_fts USING fts5(
    scope_id UNINDEXED,
    memory_artifact_id UNINDEXED,
    head_revision UNINDEXED,
    entry_id UNINDEXED,
    entry_version_id UNINDEXED,
    searchable_text,
    tokenize='unicode61'
)
"""
_DELETE_ALL_FTS_SQL = "DELETE FROM pc_memory_entry_fts"
_PROBE_FTS_SQL = "SELECT rowid FROM pc_memory_entry_fts WHERE pc_memory_entry_fts MATCH 'powercontext'"
_DELETE_MEMORY_FTS_SQL = text(
    "DELETE FROM pc_memory_entry_fts WHERE scope_id = :scope_id AND memory_artifact_id = :memory_artifact_id"
)
_DELETE_FTS_ENTRIES_SQL = text(
    "DELETE FROM pc_memory_entry_fts"
    " WHERE scope_id = :scope_id AND memory_artifact_id = :memory_artifact_id AND entry_id IN :entry_ids"
).bindparams(bindparam("entry_ids", expanding=True))
_SEARCH_FTS_SQL = text(
    """
    SELECT f.memory_artifact_id, f.head_revision, f.entry_id, f.entry_version_id, v.text
    FROM pc_memory_entry_fts AS f
    JOIN pc_memory_entry_versions AS v
      ON v.scope_id = f.scope_id
     AND v.memory_artifact_id = f.memory_artifact_id
     AND v.entry_version_id = f.entry_version_id
    WHERE pc_memory_entry_fts MATCH :query
      AND f.scope_id = :scope_id
      AND f.memory_artifact_id IN (SELECT value FROM json_each(:memory_artifact_ids))
    ORDER BY bm25(pc_memory_entry_fts), f.memory_artifact_id, f.entry_id, f.entry_version_id
    LIMIT :candidate_limit
    """
)
_INSERT_FTS_SQL = text(
    """
    INSERT INTO pc_memory_entry_fts (
        scope_id, memory_artifact_id, head_revision, entry_id,
        entry_version_id, searchable_text
    ) VALUES (
        :scope_id, :memory_artifact_id, :head_revision, :entry_id,
        :entry_version_id, :searchable_text
    )
    """
)
_TAGGED_FTS_SQL = text(str(_SEARCH_FTS_SQL).replace("ORDER BY", memory_tag_sql("f") + "ORDER BY")).bindparams(
    bindparam("tag_keys", expanding=True),
    bindparam("tag_hashes", expanding=True),
)
_DELETE_VECTOR_SQL = text("DELETE FROM pc_memory_entry_vec WHERE rowid = :vector_id")
_DELETE_ORPHAN_VECTORS_SQL = (
    "DELETE FROM pc_memory_entry_vec WHERE rowid NOT IN (SELECT vector_id FROM pc_memory_vector_entries)"
)
_INSERT_VECTOR_SQL = text("INSERT INTO pc_memory_entry_vec (rowid, embedding) VALUES (:vector_id, :embedding)")
_SELECT_VECTOR_SQL = text("SELECT embedding FROM pc_memory_entry_vec WHERE rowid = :vector_id")
_VECTOR_COMPLETENESS_SQL = text(
    """
    WITH requested AS (
        SELECT CAST(json_extract(value, '$.artifact_id') AS TEXT) AS memory_artifact_id,
               CAST(json_extract(value, '$.revision') AS INTEGER) AS head_revision
        FROM json_each(:memory_refs)
    )
    SELECT 'head' AS row_kind, h.memory_artifact_id, h.head_revision,
           h.entry_id, h.entry_version_id, h.entry_content_hash,
           NULL AS embedding_content_hash, NULL AS vector_present
    FROM pc_memory_entry_heads AS h
    JOIN requested AS r
      ON r.memory_artifact_id = h.memory_artifact_id
    WHERE h.scope_id = :scope_id
    UNION ALL
    SELECT 'artifact_head' AS row_kind, h.artifact_id, h.revision,
           NULL AS entry_id, NULL AS entry_version_id, NULL AS entry_content_hash,
           NULL AS embedding_content_hash, NULL AS vector_present
    FROM pc_artifact_heads AS h
    JOIN requested AS r ON r.memory_artifact_id = h.artifact_id
    WHERE h.scope_id = :scope_id
      AND h.family = 'memory'
    UNION ALL
    SELECT 'vector' AS row_kind, m.memory_artifact_id, m.head_revision,
           m.entry_id, m.entry_version_id, m.entry_content_hash,
           m.embedding_content_hash,
           CASE WHEN v.rowid IS NULL THEN 0 ELSE 1 END AS vector_present
    FROM pc_memory_vector_entries AS m
    JOIN requested AS r
      ON r.memory_artifact_id = m.memory_artifact_id
    LEFT JOIN pc_memory_entry_vec AS v ON v.rowid = m.vector_id
    WHERE m.scope_id = :scope_id
    """
)
_VECTOR_SEARCH_SQL = text(
    """
    WITH nearest AS (
        SELECT rowid, distance
        FROM pc_memory_entry_vec
        WHERE embedding MATCH :query_vector
          AND k = :neighbor_limit
    )
    SELECT m.memory_artifact_id, m.head_revision, m.entry_id, m.entry_version_id, v.text,
           nearest.distance
    FROM nearest
    JOIN pc_memory_vector_entries AS m ON m.vector_id = nearest.rowid
    JOIN pc_memory_entry_versions AS v
      ON v.scope_id = m.scope_id
     AND v.memory_artifact_id = m.memory_artifact_id
     AND v.entry_version_id = m.entry_version_id
    WHERE m.scope_id = :scope_id
      AND m.memory_artifact_id IN (SELECT value FROM json_each(:memory_artifact_ids))
    ORDER BY nearest.distance,
             m.memory_artifact_id, m.entry_id, m.entry_version_id
    LIMIT :candidate_limit
    """
)

# Exact distance evaluation over the eligible set avoids global KNN followed by
# post-filtering. The unfiltered path keeps its existing behavior.
_TAGGED_VECTOR_SEARCH_SQL = text(
    """
    SELECT m.memory_artifact_id, m.head_revision, m.entry_id, m.entry_version_id, v.text,
           vec_distance_L2(vec.embedding, :query_vector) AS distance
    FROM pc_memory_vector_entries AS m
    JOIN pc_memory_entry_vec AS vec ON vec.rowid = m.vector_id
    JOIN pc_memory_entry_versions AS v
      ON v.scope_id = m.scope_id
     AND v.memory_artifact_id = m.memory_artifact_id
     AND v.entry_version_id = m.entry_version_id
    WHERE m.scope_id = :scope_id
      AND m.memory_artifact_id IN (SELECT value FROM json_each(:memory_artifact_ids))
    /* tag-filter */
    ORDER BY distance, m.memory_artifact_id, m.entry_id, m.entry_version_id
    LIMIT :candidate_limit
""".replace("/* tag-filter */", memory_tag_sql("m"))
).bindparams(bindparam("tag_keys", expanding=True), bindparam("tag_hashes", expanding=True))


class SQLiteMemoryFTSIndex:
    """SQLite FTS5 strategy over rebuildable active-head projections."""

    capabilities = MemoryCapabilities(fts=True, tag_filter=True)
    tables: tuple[Table, ...] = SQLITE_MEMORY_FTS_TABLES

    async def initialize(self, connection: AsyncConnection, /) -> None:
        """Create and rebuild the FTS5 projection, failing if FTS5 is unavailable."""

        if connection.dialect.name != "sqlite":
            raise CapabilityNotSupportedError("sqlite-fts")
        await connection.exec_driver_sql(_CREATE_FTS_SQL)
        marker = await connection.scalar(select(SQLITE_MEMORY_FTS_MARKER_TABLE.c.singleton))
        if marker is None:
            await connection.execute(insert(SQLITE_MEMORY_FTS_MARKER_TABLE).values(singleton=1, schema_version=1))
        await connection.exec_driver_sql(_DELETE_ALL_FTS_SQL)
        rows = (
            await connection.execute(
                select(
                    MEMORY_ENTRY_HEADS_TABLE.c.scope_id,
                    MEMORY_ENTRY_HEADS_TABLE.c.memory_artifact_id,
                    MEMORY_ENTRY_HEADS_TABLE.c.head_revision,
                    MEMORY_ENTRY_HEADS_TABLE.c.entry_id,
                    MEMORY_ENTRY_HEADS_TABLE.c.entry_version_id,
                    MEMORY_ENTRY_HEADS_TABLE.c.searchable_text,
                )
            )
        ).mappings()
        for row in rows:
            await self._insert_row(connection, row)
        await connection.exec_driver_sql(_PROBE_FTS_SQL)

    async def replace(
        self,
        connection: AsyncConnection,
        scope_id: str,
        memory_ref: ArtifactRef,
        projections: tuple[MemoryProjection, ...],
        /,
    ) -> None:
        await connection.execute(
            _DELETE_MEMORY_FTS_SQL,
            {"scope_id": scope_id, "memory_artifact_id": memory_ref.artifact_id},
        )
        await self.upsert(connection, scope_id, memory_ref, projections)

    async def delete(
        self,
        connection: AsyncConnection,
        scope_id: str,
        memory_ref: ArtifactRef,
        entry_ids: tuple[str, ...],
        /,
    ) -> None:
        if not entry_ids:
            return
        await connection.execute(
            _DELETE_FTS_ENTRIES_SQL,
            {
                "scope_id": scope_id,
                "memory_artifact_id": memory_ref.artifact_id,
                "entry_ids": list(entry_ids),
            },
        )

    async def upsert(
        self,
        connection: AsyncConnection,
        scope_id: str,
        memory_ref: ArtifactRef,
        projections: tuple[MemoryProjection, ...],
        /,
    ) -> None:
        if not projections:
            return
        await connection.execute(
            _INSERT_FTS_SQL,
            [
                {
                    "scope_id": scope_id,
                    "memory_artifact_id": memory_ref.artifact_id,
                    "head_revision": memory_ref.revision,
                    "entry_id": projection.entry_version.entry_id,
                    "entry_version_id": projection.entry_version.entry_version_id,
                    "searchable_text": projection.searchable_text,
                }
                for projection in projections
            ],
        )

    async def search(
        self,
        connection: AsyncConnection,
        scope_id: str,
        request: MemorySearchRequest,
        /,
    ) -> MemorySearchChannels:
        if request.mode not in {"fts", "hybrid"}:
            return MemorySearchChannels()
        query = fts_match_query(request.query)
        if query is None:
            return MemorySearchChannels()
        rows = (
            await connection.execute(
                _SEARCH_FTS_SQL if request.tag_filter is None else _TAGGED_FTS_SQL,
                {
                    "query": query,
                    "scope_id": scope_id,
                    "memory_artifact_ids": json.dumps(
                        tuple(ref.artifact_id for ref in request.memories),
                        separators=(",", ":"),
                    ),
                    "candidate_limit": request.candidate_limit,
                    **memory_tag_parameters(request.tag_filter),
                },
            )
        ).mappings()
        return MemorySearchChannels(fts=memory_channel_hits(rows, request.memories))

    async def vector_complete(
        self,
        connection: AsyncConnection,
        scope_id: str,
        memories: tuple[ArtifactRef, ...],
        profile: EmbeddingProfile,
        /,
    ) -> bool:
        del connection, scope_id, memories, profile
        return False

    async def hydrate(
        self,
        connection: AsyncConnection,
        scope_id: str,
        projections: tuple[MemoryProjection, ...],
        /,
    ) -> tuple[MemoryProjection, ...]:
        del connection, scope_id
        return projections

    @staticmethod
    async def _insert_row(
        connection: AsyncConnection,
        row: Mapping[Any, Any],
    ) -> None:
        values = {
            field: row[field]
            for field in (
                "scope_id",
                "memory_artifact_id",
                "head_revision",
                "entry_id",
                "entry_version_id",
                "searchable_text",
            )
        }
        await connection.execute(_INSERT_FTS_SQL, values)


class SQLiteMemoryVectorIndex:
    """sqlite-vec strategy over rebuildable active-head embeddings."""

    tables: tuple[Table, ...] = SQLITE_MEMORY_VECTOR_TABLES

    def __init__(self, profile: EmbeddingProfile) -> None:
        if profile.dimension < 1 or profile.distance != "l2" or profile.normalization != "unit":
            raise CapabilityNotSupportedError(
                "vector",
                "sqlite-vec requires a positive unit-normalized L2 embedding profile",
            )
        self.profile = profile
        self.capabilities = MemoryCapabilities(vector=True, embedding_profile=profile, fts=False, tag_filter=True)

    async def initialize(self, connection: AsyncConnection, /) -> None:
        if connection.dialect.name != "sqlite":
            raise CapabilityNotSupportedError("sqlite-vec")
        try:
            await connection.exec_driver_sql("SELECT vec_version()")
            await connection.exec_driver_sql(
                "CREATE VIRTUAL TABLE IF NOT EXISTS pc_memory_entry_vec "
                f"USING vec0(embedding float[{self.profile.dimension}])"
            )
            probe = _pack_vector((0.0,) * self.profile.dimension)
            # A previous run may have been interrupted between inserting and deleting
            # the probe row; clear any leftover before probing again.
            await connection.execute(_DELETE_VECTOR_SQL, {"vector_id": -1})
            await connection.execute(
                _INSERT_VECTOR_SQL,
                {"vector_id": -1, "embedding": probe},
            )
            row = (
                await connection.exec_driver_sql(
                    "SELECT rowid FROM pc_memory_entry_vec WHERE embedding MATCH ? AND k = 1",
                    (probe,),
                )
            ).one_or_none()
            await connection.execute(_DELETE_VECTOR_SQL, {"vector_id": -1})
        except SQLAlchemyError as error:
            detail = await _probe_failure_detail(connection, error, self.profile.dimension)
            raise CapabilityNotSupportedError("vector", detail) from error
        if row is None or int(row[0]) != -1:
            raise CapabilityNotSupportedError("vector", "sqlite-vec probe returned an invalid row")
        # Embeddings are only reachable through their metadata rows. Drop any that
        # lost theirs, so stale neighbors cannot take the place of live entries.
        await connection.exec_driver_sql(_DELETE_ORPHAN_VECTORS_SQL)

    async def replace(
        self,
        connection: AsyncConnection,
        scope_id: str,
        memory_ref: ArtifactRef,
        projections: tuple[MemoryProjection, ...],
        /,
    ) -> None:
        existing = (
            await connection.execute(
                select(SQLITE_MEMORY_VECTOR_ENTRIES_TABLE.c.vector_id).where(
                    SQLITE_MEMORY_VECTOR_ENTRIES_TABLE.c.scope_id == scope_id,
                    SQLITE_MEMORY_VECTOR_ENTRIES_TABLE.c.memory_artifact_id == memory_ref.artifact_id,
                )
            )
        ).scalars()
        for vector_id in existing:
            await connection.execute(_DELETE_VECTOR_SQL, {"vector_id": int(vector_id)})
        await connection.execute(
            delete(SQLITE_MEMORY_VECTOR_ENTRIES_TABLE).where(
                SQLITE_MEMORY_VECTOR_ENTRIES_TABLE.c.scope_id == scope_id,
                SQLITE_MEMORY_VECTOR_ENTRIES_TABLE.c.memory_artifact_id == memory_ref.artifact_id,
            )
        )
        await self.upsert(connection, scope_id, memory_ref, projections)

    async def delete(
        self,
        connection: AsyncConnection,
        scope_id: str,
        memory_ref: ArtifactRef,
        entry_ids: tuple[str, ...],
        /,
    ) -> None:
        if not entry_ids:
            return
        metadata = SQLITE_MEMORY_VECTOR_ENTRIES_TABLE
        vector_ids = (
            await connection.execute(
                select(metadata.c.vector_id).where(
                    metadata.c.scope_id == scope_id,
                    metadata.c.memory_artifact_id == memory_ref.artifact_id,
                    metadata.c.entry_id.in_(entry_ids),
                )
            )
        ).scalars()
        for vector_id in vector_ids:
            await connection.execute(_DELETE_VECTOR_SQL, {"vector_id": int(vector_id)})
        await connection.execute(
            delete(metadata).where(
                metadata.c.scope_id == scope_id,
                metadata.c.memory_artifact_id == memory_ref.artifact_id,
                metadata.c.entry_id.in_(entry_ids),
            )
        )

    async def upsert(
        self,
        connection: AsyncConnection,
        scope_id: str,
        memory_ref: ArtifactRef,
        projections: tuple[MemoryProjection, ...],
        /,
    ) -> None:
        for projection in projections:
            if projection.embedding is None or projection.embedding_content_hash is None:
                continue
            vector = validate_embedding(projection.embedding, dimension=self.profile.dimension)
            entry = projection.entry_version
            inserted = await connection.execute(
                insert(SQLITE_MEMORY_VECTOR_ENTRIES_TABLE).values(
                    scope_id=scope_id,
                    memory_artifact_id=memory_ref.artifact_id,
                    head_revision=memory_ref.revision,
                    entry_id=entry.entry_id,
                    entry_version_id=entry.entry_version_id,
                    entry_content_hash=entry.entry_content_hash,
                    embedding_content_hash=projection.embedding_content_hash,
                )
            )
            # SQLite before 3.35 supports lastrowid, but not INSERT ... RETURNING.
            vector_id = inserted.lastrowid
            await connection.execute(
                _INSERT_VECTOR_SQL,
                {"vector_id": vector_id, "embedding": _pack_vector(vector)},
            )

    async def search(
        self,
        connection: AsyncConnection,
        scope_id: str,
        request: MemorySearchRequest,
        /,
    ) -> MemorySearchChannels:
        if request.mode not in {"vector", "hybrid"}:
            return MemorySearchChannels()
        if request.embedding_profile != self.profile or request.query_vector is None:
            raise CapabilityNotSupportedError("embedding-profile")
        if not await self.vector_complete(connection, scope_id, request.memories, self.profile):
            raise CapabilityNotSupportedError("vector")
        query_vector = _pack_vector(validate_embedding(request.query_vector, dimension=self.profile.dimension))
        total = int(await connection.scalar(select(func.count()).select_from(SQLITE_MEMORY_VECTOR_ENTRIES_TABLE)) or 0)
        if total == 0:
            return MemorySearchChannels()
        rows = (
            await connection.execute(
                _VECTOR_SEARCH_SQL if request.tag_filter is None else _TAGGED_VECTOR_SEARCH_SQL,
                {
                    "query_vector": query_vector,
                    "neighbor_limit": total,
                    **memory_tag_parameters(request.tag_filter),
                    "scope_id": scope_id,
                    "memory_artifact_ids": json.dumps(
                        tuple(ref.artifact_id for ref in request.memories),
                        separators=(",", ":"),
                    ),
                    "candidate_limit": request.candidate_limit,
                },
            )
        ).mappings()
        return MemorySearchChannels(vector=memory_channel_hits(rows, request.memories))

    async def vector_complete(
        self,
        connection: AsyncConnection,
        scope_id: str,
        memories: tuple[ArtifactRef, ...],
        profile: EmbeddingProfile,
        /,
    ) -> bool:
        if profile != self.profile:
            return False
        rows = (
            await connection.execute(
                _VECTOR_COMPLETENESS_SQL,
                {
                    "scope_id": scope_id,
                    "memory_refs": json.dumps(
                        tuple({"artifact_id": memory.artifact_id, "revision": memory.revision} for memory in memories),
                        separators=(",", ":"),
                    ),
                },
            )
        ).all()
        current_revisions = {str(row[1]): int(row[2]) for row in rows if str(row[0]) == "artifact_head"}
        if any(current_revisions.get(memory.artifact_id) != memory.revision for memory in memories):
            # The caller validated this head before the search. If it moved while
            # this query ran, report a stale head so the runtime can retry with it.
            raise CapabilityNotSupportedError("head")
        expected = {
            (str(row[1]), int(row[2]), str(row[3]), str(row[4]), str(row[5])) for row in rows if str(row[0]) == "head"
        }
        actual = {
            (str(row[1]), int(row[2]), str(row[3]), str(row[4]), str(row[5])) for row in rows if str(row[0]) == "vector"
        }
        if actual != expected:
            return False
        for row in rows:
            if str(row[0]) != "vector":
                continue
            if str(row[6]) != _embedding_hash(self.profile, str(row[5])) or not bool(row[7]):
                return False
        return True

    async def hydrate(
        self,
        connection: AsyncConnection,
        scope_id: str,
        projections: tuple[MemoryProjection, ...],
        /,
    ) -> tuple[MemoryProjection, ...]:
        hydrated: list[MemoryProjection] = []
        for projection in projections:
            entry = projection.entry_version
            metadata = (
                await connection.execute(
                    select(
                        SQLITE_MEMORY_VECTOR_ENTRIES_TABLE.c.vector_id,
                        SQLITE_MEMORY_VECTOR_ENTRIES_TABLE.c.entry_content_hash,
                        SQLITE_MEMORY_VECTOR_ENTRIES_TABLE.c.embedding_content_hash,
                    ).where(
                        SQLITE_MEMORY_VECTOR_ENTRIES_TABLE.c.scope_id == scope_id,
                        SQLITE_MEMORY_VECTOR_ENTRIES_TABLE.c.memory_artifact_id == entry.memory_artifact_id,
                        SQLITE_MEMORY_VECTOR_ENTRIES_TABLE.c.entry_id == entry.entry_id,
                        SQLITE_MEMORY_VECTOR_ENTRIES_TABLE.c.entry_version_id == entry.entry_version_id,
                    )
                )
            ).one_or_none()
            if metadata is None:
                hydrated.append(projection)
                continue
            if str(metadata[1]) != entry.entry_content_hash or str(metadata[2]) != _embedding_hash(
                self.profile, entry.entry_content_hash
            ):
                hydrated.append(projection)
                continue
            packed = (
                await connection.execute(_SELECT_VECTOR_SQL, {"vector_id": int(metadata[0])})
            ).scalar_one_or_none()
            if packed is None:
                hydrated.append(projection)
                continue
            hydrated.append(
                MemoryProjection(
                    entry_version=entry,
                    searchable_text=projection.searchable_text,
                    embedding=_unpack_vector(packed, self.profile.dimension),
                    embedding_content_hash=str(metadata[2]),
                )
            )
        return tuple(hydrated)


async def _probe_failure_detail(connection: AsyncConnection, error: SQLAlchemyError, dimension: int) -> str:
    orig = getattr(error, "orig", None)
    detail = str(orig) if orig is not None else str(error)
    existing = await _existing_vec_dimension(connection)
    if existing is not None and existing != dimension:
        return (
            "sqlite-vec probe failed: the existing pc_memory_entry_vec table dimension "
            f"{existing} does not match the configured embedding profile dimension {dimension}; "
            f"migrate the table or align the embedding dimension configuration ({detail})"
        )
    return f"sqlite-vec probe failed: {detail}"


async def _existing_vec_dimension(connection: AsyncConnection) -> int | None:
    """Return the dimension of a pre-existing vec0 table, or None when it cannot be confirmed."""

    try:
        row = (
            await connection.exec_driver_sql(
                "SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'pc_memory_entry_vec'"
            )
        ).one_or_none()
    except SQLAlchemyError:
        return None
    if row is None:
        return None
    match = search(r"float\[(\d+)\]", str(row[0]))
    return int(match.group(1)) if match is not None else None


def _pack_vector(vector: tuple[float, ...]) -> bytes:
    return struct.pack(f"={len(vector)}f", *vector)


def _unpack_vector(value: object, dimension: int) -> tuple[float, ...]:
    if not isinstance(value, bytes | bytearray | memoryview):
        raise CapabilityNotSupportedError("vector", "sqlite-vec returned an invalid vector")
    packed = bytes(value)
    if len(packed) != struct.calcsize(f"={dimension}f"):
        raise CapabilityNotSupportedError("vector", "sqlite-vec returned the wrong vector dimension")
    return tuple(struct.unpack(f"={dimension}f", packed))


def _embedding_hash(profile: EmbeddingProfile, entry_hash: str) -> str:
    return embedding_content_hash(
        profile_id=profile.profile_id,
        model=profile.model,
        dimension=profile.dimension,
        distance=profile.distance,
        normalization=profile.normalization,
        entry_content_hash=entry_hash,
    )
