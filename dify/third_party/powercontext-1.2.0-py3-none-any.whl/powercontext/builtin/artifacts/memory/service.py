# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Public orchestration for the Memory Artifact Family."""

from __future__ import annotations

import logging
from collections.abc import Callable, Sequence
from contextlib import nullcontext
from dataclasses import dataclass
from hashlib import sha256
from time import perf_counter
from typing import Literal, Protocol, TypeAlias, TypeVar, overload
from uuid import uuid4

from pydantic import BaseModel

from powercontext._logging import log_safely
from powercontext.artifacts import Artifact, ArtifactLineage, ArtifactRef
from powercontext.builtin.artifacts.memory.canonical import (
    canonical_embedding,
    canonical_error_code,
    canonical_json,
    embedding_content_hash,
    entry_content_bytes,
    entry_content_hash,
    memory_content_bytes,
    normalize_kind,
    normalize_query,
    normalize_reason,
    normalize_text,
    validate_identifier,
)
from powercontext.builtin.artifacts.memory.errors import (
    CapabilityNotSupportedError,
    InvalidEmbeddingError,
    InvalidMemoryCandidateError,
    InvalidMemoryCitationError,
    InvalidMemoryEvidenceError,
    MemoryCapacityExceededError,
    MemoryEntryInactiveError,
    MemoryEntryNotFoundError,
    MemoryWriteRejectedError,
)
from powercontext.builtin.artifacts.memory.fusion import (
    admit_fts_candidates,
    admit_vector_candidates,
    fuse_rankings,
)
from powercontext.builtin.artifacts.memory.models import (
    EmbeddingProfile,
    Memory,
    MemoryCapabilities,
    MemoryCapacity,
    MemoryCapacityBudget,
    MemoryCapacityDimension,
    MemoryChange,
    MemoryCitation,
    MemoryCompactionPolicy,
    MemoryCompactionResult,
    MemoryContent,
    MemoryEntryInput,
    MemoryEntryVersion,
    MemoryHit,
    MemoryManifest,
    MemoryManifestEntry,
    MemoryQueryEmbedding,
    MemoryRerankTrace,
    MemoryRevisionChanges,
    MemorySearchMode,
    MemorySearchResult,
    MemoryUsedSearchMode,
)
from powercontext.builtin.artifacts.memory.protocols import (
    CandidatePipeline,
    MemoryBackend,
    MemoryCandidateRequest,
    MemoryCommit,
    MemoryProjection,
    MemorySearchRequest,
    MemoryWriteAssessment,
    MemoryWriteGate,
    MemoryWriteGateRequest,
    MemoryWritePlan,
    MemoryWriteRejectionCode,
    MemoryWriteVerdict,
)
from powercontext.builtin.artifacts.memory.reranking import MemoryReranker
from powercontext.builtin.artifacts.prompt.service import ScopedPrompts, current_prompt, prompt_operation
from powercontext.builtin.artifacts.search import AdmissionCounts, AdmissionFloor, analyze_fts_query, analyze_text
from powercontext.builtin.inference import (
    EmbeddingModel,
    EmbeddingVector,
    InferenceTimeoutError,
    InferenceUnavailableError,
    embed_query,
)
from powercontext.builtin.tags import TagFilter
from powercontext.errors import RevisionConflictError
from powercontext.sources import (
    TEXT_EVIDENCE_PROJECTION_KEY,
    Source,
    SourceObservation,
    SourceProjectionKey,
    SourceRef,
    TextEvidence,
)

MemoryRememberMode: TypeAlias = Literal["append", "extract", "auto"]
IdFactory: TypeAlias = Callable[[str], str]
ValueT = TypeVar("ValueT")
_GATE_EVIDENCE_ITEM_LIMIT = 32
_GATE_EVIDENCE_TEXT_LIMIT = 2000
logger = logging.getLogger(__name__)


class _SourceResolver(Protocol):
    async def get(self, source: Source, /) -> Source: ...

    async def get_ref(self, ref: SourceRef, /) -> Source: ...

    def as_ref(self, source: Source, /) -> SourceRef: ...

    def project(self, source: Source, key: SourceProjectionKey, /) -> object: ...


class _ArtifactResolver(Protocol):
    async def get(self, artifact: Artifact[object], /) -> Artifact[object]: ...

    async def get_ref(self, ref: ArtifactRef, /) -> Artifact[object]: ...


@dataclass(frozen=True, slots=True)
class _OperationEvidence:
    sources: tuple[Source, ...]
    artifacts: tuple[Artifact[object], ...]


@dataclass(frozen=True, slots=True)
class _EntryMaterial:
    kind: str
    text: str
    sources: tuple[SourceRef, ...]
    artifacts: tuple[ArtifactRef, ...]
    content_bytes: bytes
    content_hash: str


@dataclass(frozen=True, slots=True)
class _GateEvidenceEntry:
    text: str
    complete: bool


@dataclass(frozen=True, slots=True)
class _GateCandidateEvidence:
    index: int
    material: _EntryMaterial


@dataclass(frozen=True, slots=True)
class _GateEvidenceProjection:
    entries: tuple[str, ...]
    rejection: MemoryWriteAssessment | None = None


@dataclass(slots=True)
class _GateEvidenceBuilder:
    policy_id: str
    entries: list[str]

    def append(self, entry: _GateEvidenceEntry) -> MemoryWriteAssessment | None:
        if not entry.complete:
            return self._budget_rejection()
        if any(current == entry.text for current in self.entries):
            return None
        if len(self.entries) >= _GATE_EVIDENCE_ITEM_LIMIT:
            return self._budget_rejection()
        self.entries.append(entry.text)
        return None

    def projection(self) -> _GateEvidenceProjection:
        return _GateEvidenceProjection(tuple(self.entries))

    def _budget_rejection(self) -> MemoryWriteAssessment:
        return MemoryWriteAssessment(
            verdict=MemoryWriteVerdict.HOLD,
            policy_id=self.policy_id,
            code=MemoryWriteRejectionCode.EVIDENCE_LIMIT_EXCEEDED,
            reason="the cited evidence exceeds the gate evidence budget",
        )


class _InvalidMemoryOperationError(ValueError):
    def __init__(self, code: str) -> None:
        messages = {
            "append-entries": "memory append mode requires at least one entry",
            "extract-evidence": "memory extract mode requires evidence and does not accept entries",
            "no-work": "memory remember call has no executable work",
            "duplicate-target": "a memory entry can only be targeted once per operation",
            "id-collision": "generated memory identity collides with current content",
            "organize-mode": "unsupported memory organize mode",
            "since-greater": "since_revision cannot be greater than the target Revision",
            "since-negative": "since_revision cannot be negative",
            "search-memories": "memory search requires at least one explicit Memory ref",
            "search-limit": "memory search limit must be positive",
            "search-mode": "unsupported memory search mode",
            "search-query": "memory search query must be non-empty text",
            "compaction-limit": "memory compaction limit must be positive",
            "history-limit": "memory history revision limit must be positive",
            "through-range": "through_revision must be between 1 and the current head Revision",
        }
        super().__init__(messages[code])


def _extraction_prompt_refs() -> tuple[ArtifactRef, ...]:
    selection = current_prompt("memory.extract")
    return () if selection is None or selection.artifact is None else (selection.artifact,)


def _require_tag_filter(capabilities: MemoryCapabilities, tag_filter: TagFilter | None) -> None:
    if tag_filter is not None and not capabilities.tag_filter:
        raise CapabilityNotSupportedError("tag-filter")


def _annotate_reason(reason: str | None, flagged_reason: str | None) -> str | None:
    """Fill a missing audit reason from a flagged gate verdict without overwriting a caller's."""

    normalized = normalize_reason(reason)
    if normalized is not None or flagged_reason is None:
        return normalized
    return normalize_reason(flagged_reason)


class MemoryService:
    """Validate and orchestrate Memory operations without exposing storage details."""

    def __init__(
        self,
        *,
        backend: MemoryBackend,
        candidate_pipeline: CandidatePipeline | None = None,
        embedding_model: EmbeddingModel | None = None,
        reranker: MemoryReranker | None = None,
        rerank_candidate_limit: int = 30,
        source_resolver: _SourceResolver | None = None,
        artifact_resolver: _ArtifactResolver | None = None,
        id_factory: IdFactory | None = None,
        prompt_context: ScopedPrompts | None = None,
        write_gate: MemoryWriteGate | None = None,
        capacity_budget: MemoryCapacityBudget | None = None,
        compaction: MemoryCompactionPolicy | None = None,
        max_history_revisions: int = 100,
    ) -> None:
        self._backend = backend
        self._prompt_context = prompt_context
        self._candidate_pipeline = candidate_pipeline
        self._write_gate = write_gate
        self._embedding_model = embedding_model
        if rerank_candidate_limit < 1:
            raise _InvalidMemoryOperationError("search-limit")
        self._reranker = reranker
        self._rerank_candidate_limit = rerank_candidate_limit
        self._source_resolver = source_resolver
        self._artifact_resolver = artifact_resolver
        self._id_factory = _default_id if id_factory is None else id_factory
        self._capacity_budget = MemoryCapacityBudget() if capacity_budget is None else capacity_budget.model_copy()
        self._compaction = MemoryCompactionPolicy() if compaction is None else compaction.model_copy()
        if max_history_revisions < 1:
            raise _InvalidMemoryOperationError("history-limit")
        self._max_history_revisions = max_history_revisions
        # One entry, describing the projections of the most recently written Memory
        # revision. Revisions are immutable, so a hit is always valid for that exact
        # reference; a rebuilt or externally advanced Memory simply misses.
        self._previous_projection_cache: tuple[ArtifactRef, dict[str, MemoryProjection]] | None = None

    async def get(self, memory: Memory, /) -> Memory:
        """Return the canonical exact Memory Revision matching ``memory``."""

        return await self._canonical_memory(memory)

    async def latest(self, memory: Memory, /) -> Memory:
        """Return the current head of the same Memory identity."""

        canonical = await self.get(memory)
        return await self._backend.latest(canonical.artifact_id)

    async def revisions(
        self, memory: Memory, /, *, since_revision: int = 0, through_revision: int | None = None
    ) -> tuple[Memory, ...]:
        """Return history in ascending order within ``(since_revision, through_revision]``.

        The upper bound defaults to the current head. The history limit applies
        to the requested interval, and oversized intervals are never truncated.
        """

        canonical = await self.get(memory)
        latest = await self._backend.latest(canonical.artifact_id)
        upper = latest.revision if through_revision is None else through_revision
        if upper < 1 or upper > latest.revision:
            raise _InvalidMemoryOperationError("through-range")
        if since_revision < 0:
            raise _InvalidMemoryOperationError("since-negative")
        if since_revision > upper:
            raise _InvalidMemoryOperationError("since-greater")
        if upper - since_revision > self._max_history_revisions:
            raise CapabilityNotSupportedError("history-window")
        history = []
        for revision in range(since_revision + 1, upper + 1):
            history.append(
                await self._backend.get(
                    ArtifactRef(family=Memory.family, artifact_id=canonical.artifact_id, revision=revision)
                )
            )
        return tuple(history)

    async def head(self, artifact_id: str, /) -> Memory:
        """Return the current Memory head by its stable Artifact identity."""

        return await self._backend.latest(artifact_id)

    async def capacity(self, memory: Memory, /) -> MemoryCapacity:
        """Measure an exact Revision, including eligible tombstones even when compaction is disabled.

        Eligibility can load complete manifests across the tombstone recovery
        window. Cost scales with their combined size; this is not a cheap counter.
        """

        canonical = await self._canonical_memory(memory)
        values = self._capacity_values(canonical.content)
        return MemoryCapacity(
            memory_ref=canonical.as_ref(),
            active_entry_count=values["active_entries"],
            manifest_entry_count=values["manifest_entries"],
            manifest_bytes=values["manifest_bytes"],
            compactable_entry_count=len(await self._compactable_entry_ids(canonical)),
            budget=self._capacity_budget.model_copy(),
            exceeded=tuple(dimension for dimension, limit in self._capacity_limits() if values[dimension] > limit),
        )

    def _capacity_limits(self) -> tuple[tuple[MemoryCapacityDimension, int], ...]:
        budget = self._capacity_budget
        return (
            ("manifest_bytes", budget.max_manifest_bytes),
            ("manifest_entries", budget.max_manifest_entries),
            ("active_entries", budget.max_active_entries),
        )

    @staticmethod
    def _capacity_values(
        content: MemoryContent, content_bytes: bytes | None = None
    ) -> dict[MemoryCapacityDimension, int]:
        return {
            "manifest_bytes": len(memory_content_bytes(content) if content_bytes is None else content_bytes),
            "manifest_entries": len(content.manifest.entries),
            "active_entries": sum(item.state == "active" for item in content.manifest.entries),
        }

    def _require_capacity(
        self,
        base: Memory | None,
        content: MemoryContent,
        *,
        growth: frozenset[MemoryCapacityDimension],
        content_bytes: bytes,
    ) -> None:
        if not growth:
            return
        values = self._capacity_values(content, content_bytes)
        previous = None
        for dimension, limit in self._capacity_limits():
            observed = values[dimension]
            if dimension not in growth or observed <= limit:
                continue
            if previous is None:
                previous = {} if base is None else self._capacity_values(base.content)
            if observed > previous.get(dimension, 0):
                raise MemoryCapacityExceededError(dimension, limit, observed)

    async def _compactable_entry_ids(self, memory: Memory) -> tuple[str, ...]:
        inactive = {item.entry_id for item in memory.content.manifest.entries if item.state == "inactive"}
        if not inactive:
            return ()
        # Only the recovery window matters. An inactive entry untouched throughout
        # that window was already inactive at its lower bound.
        lower = max(0, memory.revision - self._compaction.min_tombstone_revisions)
        if lower < 1:
            return ()
        recent = {
            change.entry_id
            for revision in await self._backend.changes(memory.as_ref(), lower)
            for change in revision.changes
            if change.op in {"add", "deactivate", "reactivate"}
        }
        tagged = await self._backend.any_tagged_entry_ids(memory.as_ref())
        return tuple(sorted(inactive - recent - tagged, key=str.encode))

    async def compact(
        self, memory: Memory, *, dry_run: bool = False, limit: int | None = None, reason: str | None = None
    ) -> MemoryCompactionResult:
        """Drop aged, untagged tombstones; retain every prior Revision and entry body.

        Previews are available while compaction is disabled. Reclaimed bytes are
        the signed difference of complete canonical contents, including the audit
        changes and reason, which can outweigh a small manifest reduction.
        """

        if limit is not None and limit < 1:
            raise _InvalidMemoryOperationError("compaction-limit")
        if not dry_run and not self._compaction.enabled:
            raise CapabilityNotSupportedError("compaction")
        normalized_reason = normalize_reason(reason)
        base = await self._canonical_base(memory)
        entry_ids = (await self._compactable_entry_ids(base))[:limit]
        selected = frozenset(entry_ids)
        manifest = {item.entry_id: item for item in base.content.manifest.entries if item.entry_id not in selected}
        changes = tuple(
            MemoryChange(
                op="compact",
                entry_id=item.entry_id,
                from_entry_version_id=item.entry_version_id,
                to_entry_version_id=None,
                reason=normalized_reason,
            )
            for item in base.content.manifest.entries
            if item.entry_id in selected
        )
        if not entry_ids:
            return MemoryCompactionResult(memory=base, dry_run=dry_run)
        content = MemoryContent(manifest=MemoryManifest(entries=tuple(manifest.values())), changes=changes)
        reclaimed = len(memory_content_bytes(base.content)) - len(memory_content_bytes(content))
        result = (
            base
            if dry_run
            else await self._commit_existing_transition(
                base=base,
                manifest=manifest,
                changes=changes,
                current_by_entry={},
                entry_versions=(),
            )
        )
        return MemoryCompactionResult(memory=result, entry_ids=entry_ids, reclaimed_bytes=reclaimed, dry_run=dry_run)

    async def head_entries(self, artifact_id: str, /) -> tuple[Memory, tuple[MemoryEntryVersion, ...]]:
        """Return the current Memory head together with its validated entry objects.

        ``entries`` re-reads the caller's Memory to prove it matches storage, which a head
        read straight from the backend already satisfies. Callers that need both the head
        and its entries use this instead, so a read-only pass over many Scopes does not
        re-fetch every Memory Revision it just loaded.
        """

        memory = await self._backend.latest(artifact_id)
        return memory, await self._validated_entries(memory)

    async def revision(self, memory: ArtifactRef, /) -> Memory:
        """Return one exact Memory Revision by its stable reference."""

        return await self._backend.get(memory)

    async def remember(
        self,
        *,
        memory: Memory | None,
        sources: Sequence[Source] = (),
        artifacts: Sequence[Artifact[object]] = (),
        entries: Sequence[MemoryEntryInput] = (),
        mode: MemoryRememberMode = "auto",
    ) -> Memory | None:
        """Append or extract validated entry changes against one exact head."""

        plan = await self.plan_remember(
            memory=memory,
            sources=sources,
            artifacts=artifacts,
            entries=entries,
            mode=mode,
        )
        _raise_if_write_held(plan)
        return await self.apply(plan)

    async def plan_remember(
        self,
        *,
        memory: Memory | None,
        sources: Sequence[Source] = (),
        artifacts: Sequence[Artifact[object]] = (),
        entries: Sequence[MemoryEntryInput] = (),
        mode: MemoryRememberMode = "auto",
    ) -> MemoryWritePlan:
        """Validate and prepare a write without mutating authoritative storage."""

        selected_mode = _select_remember_mode(
            mode,
            has_entries=bool(entries),
            has_evidence=bool(sources or artifacts),
        )
        binding = (
            self._prompt_context.service.bind(self._prompt_context.scope_id, "memory.extract")
            if selected_mode == "extract" and self._prompt_context is not None
            else nullcontext()
        )
        async with binding:
            base = await self._canonical_base(memory)
            evidence = await self._canonical_operation_evidence(sources, artifacts)
            # Only extraction compares against every current entry; append plans carry
            # no current entry set and load one lazily if a candidate revises an entry.
            current_entries = (
                await self._validated_entries(base) if base is not None and selected_mode == "extract" else None
            )
            candidates = await self._candidates(
                selected_mode,
                tuple(entries),
                evidence,
                () if current_entries is None else current_entries,
                active_version_ids=(
                    frozenset()
                    if base is None
                    else frozenset(
                        item.entry_version_id for item in base.content.manifest.entries if item.state == "active"
                    )
                ),
            )
            if not candidates:
                return MemoryWritePlan(result=base, commit=None)

            assessment = await self._assess_write(base, candidates, evidence, current_entries)
            if assessment is not None and assessment.verdict is MemoryWriteVerdict.HOLD:
                # A refused write stays visible: the caller reads the structured code and reason
                # from the plan. The plan carries no commit, so nothing is written.
                return MemoryWritePlan(result=base, commit=None, decision=assessment)

            flagged_reason = (
                assessment.reason if assessment is not None and assessment.verdict is MemoryWriteVerdict.FLAG else None
            )
            commit = await self._prepare_commit(
                base=base,
                candidates=candidates,
                evidence=evidence,
                current_entries=current_entries,
                flagged_reason=flagged_reason,
            )
            if commit is None:
                return MemoryWritePlan(result=base, commit=None, decision=assessment)
            return MemoryWritePlan(result=commit.memory, commit=commit, decision=assessment)

    async def apply(self, plan: MemoryWritePlan, /) -> Memory | None:
        """Apply one prepared write through this service's transaction boundary."""

        if plan.commit is None:
            return plan.result
        async with self._backend.begin() as unit_of_work:
            committed = await unit_of_work.commit(plan.commit)
        if plan.result != committed:
            raise InvalidMemoryCitationError("memory-mismatch")
        self._cache_projections(committed, plan.commit.projections)
        return committed

    async def forget(
        self,
        memory: Memory,
        *,
        entries: Sequence[MemoryEntryVersion],
        reason: str | None = None,
    ) -> Memory:
        """Deactivate logical entries without deleting immutable content."""

        return await self._set_entry_state(
            memory,
            entries=entries,
            target_state="inactive",
            reason=reason,
        )

    async def reactivate(
        self,
        memory: Memory,
        *,
        entries: Sequence[MemoryEntryVersion],
        reason: str | None = None,
    ) -> Memory:
        """Restore inactive logical entries without creating body versions."""

        return await self._set_entry_state(
            memory,
            entries=entries,
            target_state="active",
            reason=reason,
        )

    async def organize(
        self,
        memory: Memory,
        *,
        mode: Literal["default", "dedupe", "normalize"] = "default",
    ) -> Memory:
        """Apply only exact deduplication and canonical normalization."""

        if mode not in {"default", "dedupe", "normalize"}:
            raise _InvalidMemoryOperationError("organize-mode")
        base = await self._canonical_base(memory)
        current_entries = await self._validated_entries(base)
        manifest = {entry.entry_id: entry for entry in base.content.manifest.entries}
        current_by_entry = {entry.entry_id: entry for entry in current_entries}
        changes: list[MemoryChange] = []
        changed_ids: set[str] = set()
        new_versions: list[MemoryEntryVersion] = []

        if mode in {"default", "dedupe"}:
            dedupe_changes, changed_ids = self._deduplicate_manifest(manifest, current_by_entry)
            changes.extend(dedupe_changes)

        if mode in {"default", "normalize"}:
            normalize_changes, new_versions = self._normalize_manifest_entries(
                base,
                manifest,
                current_by_entry,
                skip=changed_ids,
            )
            changes.extend(normalize_changes)

        if not changes:
            return base
        return await self._commit_existing_transition(
            base=base,
            manifest=manifest,
            changes=changes,
            current_by_entry=current_by_entry,
            entry_versions=tuple(new_versions),
        )

    async def changes(
        self,
        memory: Memory,
        *,
        since_revision: int | None = None,
    ) -> tuple[MemoryRevisionChanges, ...]:
        """Read compact change summaries without expanding entry bodies."""

        target = await self._canonical_memory(memory)
        if since_revision is not None:
            if since_revision < 0:
                raise _InvalidMemoryOperationError("since-negative")
            if since_revision > target.revision:
                raise _InvalidMemoryOperationError("since-greater")
            if since_revision == target.revision:
                return ()
            if since_revision > 0:
                await self._backend.get(
                    ArtifactRef(
                        family=Memory.family,
                        artifact_id=target.artifact_id,
                        revision=since_revision,
                    )
                )
        return await self._backend.changes(target.as_ref(), since_revision)

    @prompt_operation("memory.rerank")
    async def search(
        self,
        query: str,
        *,
        memories: Sequence[Memory],
        limit: int = 10,
        mode: MemorySearchMode = "auto",
        tag_filter: TagFilter | None = None,
        admission: AdmissionFloor | None = None,
        query_embedding: MemoryQueryEmbedding | None = None,
    ) -> MemorySearchResult:
        """Search explicit current Memory heads with capability-safe fallback.

        ``admission=None`` applies the historical fusion-time thresholds bit for bit.

        ``query_embedding`` lets a caller reuse a vector it already paid for (RFC 1560's
        expansion rounds reuse the round-0 vector). Reuse is best-effort and honest: it is
        applied only when the supplied profile equals the one this search resolved, and the
        call reports ``embedding_calls = 0`` in that case, ``1`` when it embedded. The
        resolved vector is handed back on :attr:`MemorySearchResult.query_embedding` so the
        next round can reuse it. When the mode resolved to ``fts`` there is no vector to
        report, so the field stays ``None`` and the next round must pay again.
        """

        if not memories:
            raise _InvalidMemoryOperationError("search-memories")
        if limit < 1:
            raise _InvalidMemoryOperationError("search-limit")
        if mode not in {"fts", "vector", "hybrid", "auto"}:
            raise _InvalidMemoryOperationError("search-mode")
        selected_by_ref: dict[tuple[str, str, int], Memory] = {}
        for memory in memories:
            ref = memory.as_ref()
            selected_by_ref.setdefault((ref.family, ref.artifact_id, ref.revision), memory)
        selected = tuple(selected_by_ref.values())
        selected_memories = tuple(memory.as_ref() for memory in selected)
        await self._validate_search_heads(selected)
        capabilities = await self._backend.capabilities()
        _require_tag_filter(capabilities, tag_filter)
        selected_mode = await self._select_search_mode(
            mode,
            memories=selected_memories,
            capabilities=capabilities,
        )
        try:
            normalized_query = normalize_query(query)
        except (TypeError, ValueError) as error:
            raise _InvalidMemoryOperationError("search-query") from error
        query_vector = None
        profile = None
        embedding_calls = 0
        resolved_embedding: MemoryQueryEmbedding | None = None
        if selected_mode in {"vector", "hybrid"}:
            profile = capabilities.embedding_profile
            if profile is None:
                raise CapabilityNotSupportedError(selected_mode)
            if profile.distance != "l2" or profile.normalization != "unit":
                raise CapabilityNotSupportedError(
                    selected_mode,
                    "cosine admission requires a unit-normalized L2 embedding profile",
                )
            (
                selected_mode,
                query_vector,
                resolved_embedding,
                embedding_calls,
            ) = await self._resolve_query_vector(
                query=normalized_query,
                requested_mode=mode,
                selected_mode=selected_mode,
                profile=profile,
                capabilities=capabilities,
                reuse=query_embedding,
            )
            if resolved_embedding is None:
                profile = None
        coarse_limit = limit if self._reranker is None else max(limit, self._rerank_candidate_limit)
        request = MemorySearchRequest(
            query=normalized_query,
            analyzed_query=analyze_fts_query(normalized_query),
            memories=selected_memories,
            candidate_limit=max(coarse_limit * 4, 32),
            mode=selected_mode,
            query_vector=query_vector,
            embedding_profile=profile,
            tag_filter=tag_filter,
        )
        channels = await self._backend.search(request)
        admitted_fts = admit_fts_candidates(normalized_query, channels.fts, admission=admission)
        admitted_vector = admit_vector_candidates(channels.vector, admission=admission)
        hits = fuse_rankings(
            fts=admitted_fts if selected_mode in {"fts", "hybrid"} else (),
            vector=admitted_vector if selected_mode in {"vector", "hybrid"} else (),
            limit=coarse_limit,
        )
        return await self._reranked_search_result(
            mode=selected_mode,
            query=normalized_query,
            hits=hits,
            limit=limit,
            admission=AdmissionCounts(
                family=Memory.family,
                scope_id="",
                retrieved=len(channels.fts) + len(channels.vector),
                admitted=len(admitted_fts) + len(admitted_vector),
            ),
            embedding_calls=embedding_calls,
            query_embedding=resolved_embedding,
        )

    async def _resolve_query_vector(
        self,
        *,
        query: str,
        requested_mode: MemorySearchMode,
        selected_mode: MemoryUsedSearchMode,
        profile: EmbeddingProfile,
        capabilities: MemoryCapabilities,
        reuse: MemoryQueryEmbedding | None,
    ) -> tuple[MemoryUsedSearchMode, tuple[float, ...] | None, MemoryQueryEmbedding | None, int]:
        """Resolve — or reuse — the query vector for a vector or hybrid search.

        Returns ``(selected_mode, query_vector, resolved_embedding, embedding_calls)``.
        ``resolved_embedding`` is ``None`` exactly when the search fell back to ``fts``, which
        is also when the caller must drop the embedding profile from the backend request.

        Reuse applies only when the supplied profile equals the resolved one; otherwise the
        round embeds and reports one call. A failed embedding is still counted as one call,
        because the call was issued — the cost is real even though it produced nothing.
        """

        if reuse is not None and reuse.embedding_profile == profile:
            return selected_mode, reuse.query_vector, reuse, 0
        try:
            query_vector = (await self._embed_texts((query,), profile, query=True))[0]
        except (InferenceUnavailableError, InferenceTimeoutError) as error:
            if requested_mode == "auto" and capabilities.fts:
                return "fts", None, None, 1
            raise CapabilityNotSupportedError(
                selected_mode,
                "embedding model is temporarily unavailable",
            ) from error
        return (
            selected_mode,
            query_vector,
            MemoryQueryEmbedding(query_vector=query_vector, embedding_profile=profile),
            1,
        )

    async def _reranked_search_result(
        self,
        *,
        mode: MemoryUsedSearchMode,
        query: str,
        hits: tuple[MemoryHit, ...],
        limit: int,
        admission: AdmissionCounts | None = None,
        embedding_calls: int = 0,
        query_embedding: MemoryQueryEmbedding | None = None,
    ) -> MemorySearchResult:
        """Apply the optional reranker and report what this search paid and admitted.

        ``generation_calls`` counts the RFC 0080 rerank call this search actually issued: ``1``
        when the reranker ran over a non-empty pool, ``0`` otherwise. It is never inferred
        from configuration — a deployment whose rerank flag is on but whose reranker did not
        run reports ``0``, which is the honest number.
        """

        if self._reranker is None or not hits:
            return MemorySearchResult(
                mode=mode,
                hits=hits[:limit],
                admission=admission,
                embedding_calls=embedding_calls,
                query_embedding=query_embedding,
            )
        rerank_started = perf_counter()
        decision = await self._reranker.rerank(
            query,
            hits,
            min(limit, len(hits)),
        )
        rerank_latency_ms = (perf_counter() - rerank_started) * 1_000
        selected = tuple(hits[rank - 1] for rank in decision.selected_ranks)
        return MemorySearchResult(
            mode=mode,
            hits=selected,
            rerank=MemoryRerankTrace(
                policy_id=self._reranker.policy_id,
                candidate_hits=hits,
                selected_ranks=decision.selected_ranks,
                discarded_rank_count=decision.discarded_rank_count,
                used_fallback=decision.used_fallback,
                latency_ms=rerank_latency_ms,
                usage=decision.usage,
            ),
            admission=admission,
            embedding_calls=embedding_calls,
            generation_calls=1,
            query_embedding=query_embedding,
        )

    async def expand(
        self,
        hits: Sequence[MemoryHit],
        *,
        layer: Literal["full"] = "full",
    ) -> tuple[MemoryEntryVersion, ...]:
        """Expand exact hit anchors and reject cross-Revision substitutions."""

        if layer != "full":
            raise CapabilityNotSupportedError("expand-layer")
        hit_tuple = tuple(hits)
        versions = await self._backend.expand(hit_tuple)
        if len(versions) != len(hit_tuple):
            raise InvalidMemoryCitationError("expand-count")
        for hit, version in zip(hit_tuple, versions, strict=True):
            await self._validate_anchor(
                memory_ref=hit.memory_ref,
                entry_id=hit.entry_id,
                entry_version_id=hit.entry_version_id,
                version=version,
            )
        return versions

    async def entries(
        self, memory: Memory, /, *, tag_filter: TagFilter | None = None
    ) -> tuple[MemoryEntryVersion, ...]:
        """Return the entry objects referenced by one exact current Memory head."""

        canonical = await self._canonical_memory(memory)
        entries = await self._validated_entries(canonical)
        if tag_filter is None:
            return entries
        _require_tag_filter(await self._backend.capabilities(), tag_filter)
        matching = await self._backend.tagged_entry_ids(canonical.as_ref(), tag_filter)
        return tuple(entry for entry in entries if entry.entry_id in matching)

    async def rebuild_projections(self, embedding_model: EmbeddingModel | None = None, /) -> None:
        """Rebuild current-head search projections from authoritative Memory revisions."""

        self._previous_projection_cache = None
        await self._backend.rebuild_projections(embedding_model)

    async def validate_citation(self, citation: MemoryCitation) -> MemoryEntryVersion:
        """Resolve one exact Handoff citation."""

        hit = MemoryHit(
            memory_ref=citation.memory_ref,
            entry_id=citation.entry_id,
            entry_version_id=citation.entry_version_id,
            text="",
            score=0.0,
            matched_by=(),
        )
        return (await self.expand((hit,)))[0]

    async def _validate_search_heads(self, memories: tuple[Memory, ...]) -> None:
        for memory in memories:
            exact = await self._backend.get(memory.as_ref())
            latest = await self._backend.latest(memory.artifact_id)
            if exact != memory or exact.as_ref() != latest.as_ref():
                raise CapabilityNotSupportedError("head")

    async def _select_search_mode(
        self,
        requested: MemorySearchMode,
        *,
        memories: tuple[ArtifactRef, ...],
        capabilities: MemoryCapabilities,
    ) -> MemoryUsedSearchMode:
        if requested == "fts":
            if not capabilities.fts:
                raise CapabilityNotSupportedError("fts")
            return "fts"

        embedding_profile = None if self._embedding_model is None else self._embedding_model.profile
        profile = capabilities.embedding_profile
        profile_matches = profile is not None and embedding_profile == profile
        vector_complete = (
            await self._backend.vector_complete(memories, profile)
            if capabilities.vector and profile_matches and profile is not None
            else False
        )
        vector_available = capabilities.vector and profile_matches and vector_complete
        hybrid_available = capabilities.hybrid and vector_available

        if requested == "vector":
            if not vector_available:
                raise CapabilityNotSupportedError("vector")
            return "vector"
        if requested == "hybrid":
            if not hybrid_available:
                raise CapabilityNotSupportedError("hybrid")
            return "hybrid"
        if requested == "auto":
            if hybrid_available:
                return "hybrid"
            if capabilities.fts:
                return "fts"
            raise CapabilityNotSupportedError("fts")
        raise _InvalidMemoryOperationError("search-mode")

    def _deduplicate_manifest(
        self,
        manifest: dict[str, MemoryManifestEntry],
        current_by_entry: dict[str, MemoryEntryVersion],
    ) -> tuple[list[MemoryChange], set[str]]:
        groups: dict[bytes, list[str]] = {}
        for item in manifest.values():
            if item.state == "active":
                material = self._material_from_version(current_by_entry[item.entry_id])
                groups.setdefault(material.content_bytes, []).append(item.entry_id)

        changes: list[MemoryChange] = []
        changed_ids: set[str] = set()
        for entry_ids in groups.values():
            ordered = sorted(entry_ids, key=str.encode)
            for entry_id in ordered[1:]:
                item = manifest[entry_id]
                manifest[entry_id] = item.model_copy(update={"state": "inactive"})
                changes.append(
                    MemoryChange(
                        op="deactivate",
                        entry_id=entry_id,
                        from_entry_version_id=item.entry_version_id,
                        to_entry_version_id=None,
                        reason="dedupe",
                    )
                )
                changed_ids.add(entry_id)
        return changes, changed_ids

    def _normalize_manifest_entries(
        self,
        base: Memory,
        manifest: dict[str, MemoryManifestEntry],
        current_by_entry: dict[str, MemoryEntryVersion],
        *,
        skip: set[str],
    ) -> tuple[list[MemoryChange], list[MemoryEntryVersion]]:
        changes: list[MemoryChange] = []
        new_versions: list[MemoryEntryVersion] = []
        for entry_id, previous in tuple(current_by_entry.items()):
            if entry_id in skip:
                continue
            material = self._material_from_version(previous)
            if _is_canonical_version(previous, material):
                continue
            version = self._new_entry_version(
                memory_id=base.artifact_id,
                entry_id=entry_id,
                previous=previous,
                material=material,
                created_in_revision=base.revision + 1,
            )
            item = manifest[entry_id]
            manifest[entry_id] = _manifest_entry(version, state=item.state)
            current_by_entry[entry_id] = version
            new_versions.append(version)
            changes.append(
                MemoryChange(
                    op="revise",
                    entry_id=entry_id,
                    from_entry_version_id=previous.entry_version_id,
                    to_entry_version_id=version.entry_version_id,
                    reason="normalize",
                )
            )
        return changes, new_versions

    async def _set_entry_state(
        self,
        memory: Memory,
        *,
        entries: Sequence[MemoryEntryVersion],
        target_state: Literal["active", "inactive"],
        reason: str | None,
    ) -> Memory:
        base = await self._canonical_base(memory)
        current_entries = await self._validated_entries(base)
        manifest = {entry.entry_id: entry for entry in base.content.manifest.entries}
        current_by_entry = {entry.entry_id: entry for entry in current_entries}
        normalized_reason = normalize_reason(reason)
        changes: list[MemoryChange] = []

        seen: set[tuple[str, str]] = set()
        for entry in entries:
            identity = (entry.entry_id, entry.entry_version_id)
            if identity in seen:
                continue
            seen.add(identity)
            entry_id = validate_identifier(entry.entry_id)
            item = manifest.get(entry_id)
            if item is None:
                raise MemoryEntryNotFoundError(entry_id)
            current = current_by_entry.get(entry_id)
            if current is None:
                raise MemoryEntryNotFoundError(entry_id)
            if entry != current:
                raise InvalidMemoryCitationError("entry-mismatch")
            if item.state == target_state:
                continue
            manifest[entry_id] = item.model_copy(update={"state": target_state})
            changes.append(
                MemoryChange(
                    op="reactivate" if target_state == "active" else "deactivate",
                    entry_id=entry_id,
                    from_entry_version_id=None if target_state == "active" else item.entry_version_id,
                    to_entry_version_id=item.entry_version_id if target_state == "active" else None,
                    reason=normalized_reason,
                )
            )

        if not changes:
            return base
        return await self._commit_existing_transition(
            base=base,
            manifest=manifest,
            changes=changes,
            current_by_entry=current_by_entry,
            entry_versions=(),
            growth=frozenset({"active_entries"}) if target_state == "active" else frozenset(),
        )

    async def _commit_existing_transition(
        self,
        *,
        base: Memory,
        manifest: dict[str, MemoryManifestEntry],
        changes: Sequence[MemoryChange],
        current_by_entry: dict[str, MemoryEntryVersion],
        entry_versions: tuple[MemoryEntryVersion, ...],
        growth: frozenset[MemoryCapacityDimension] = frozenset(),
    ) -> Memory:
        sorted_manifest = tuple(sorted(manifest.values(), key=lambda item: item.entry_id.encode("utf-8")))
        sorted_changes = tuple(sorted(changes, key=lambda change: change.entry_id.encode("utf-8")))
        content = MemoryContent(manifest=MemoryManifest(entries=sorted_manifest), changes=sorted_changes)
        content_bytes = memory_content_bytes(content)
        self._require_capacity(base, content, growth=growth, content_bytes=content_bytes)
        memory = Memory(
            artifact_id=base.artifact_id,
            revision=base.revision + 1,
            content=content,
            lineage=ArtifactLineage(),
        )
        projections = await self._prepare_projections(
            base=base,
            manifest_entries=sorted_manifest,
            versions_by_entry=current_by_entry,
            changed_version_ids=frozenset(version.entry_version_id for version in entry_versions),
        )
        commit = MemoryCommit(
            base=base,
            memory=memory,
            content_hash=sha256(content_bytes).hexdigest(),
            entry_versions=entry_versions,
            projections=projections,
        )
        async with self._backend.begin() as unit_of_work:
            committed = await unit_of_work.commit(commit)
        self._cache_projections(committed, commit.projections)
        return committed

    async def _validate_anchor(
        self,
        *,
        memory_ref: ArtifactRef,
        entry_id: str,
        entry_version_id: str,
        version: MemoryEntryVersion,
    ) -> None:
        memory = await self._backend.get(memory_ref)
        item = next(
            (candidate for candidate in memory.content.manifest.entries if candidate.entry_id == entry_id),
            None,
        )
        if (
            item is None
            or item.entry_version_id != entry_version_id
            or version.memory_artifact_id != memory_ref.artifact_id
            or version.entry_id != entry_id
            or version.entry_version_id != entry_version_id
        ):
            raise InvalidMemoryCitationError("expand-anchor")
        material = self._material_from_version(version)
        if material.content_hash != item.entry_content_hash or version.entry_content_hash != item.entry_content_hash:
            raise InvalidMemoryCitationError("hash-mismatch")

    async def _prepare_projections(
        self,
        *,
        base: Memory | None,
        manifest_entries: tuple[MemoryManifestEntry, ...],
        versions_by_entry: dict[str, MemoryEntryVersion],
        changed_version_ids: frozenset[str],
    ) -> tuple[MemoryProjection, ...]:
        """Build active-head projections, reusing unchanged vectors and embedding only changes."""

        previous = await self._previous_projections(base)
        prepared: list[MemoryProjection] = []
        embed_indices: list[int] = []
        for item in manifest_entries:
            if item.state != "active":
                continue
            replayed = previous.get(item.entry_version_id)
            if replayed is not None and item.entry_version_id not in changed_version_ids:
                # Entry versions are immutable, so the projection recorded for this
                # version id is exactly what this revision carries; re-deriving it
                # would re-analyze every unchanged entry on every write.
                prepared.append(replayed)
                continue
            version = versions_by_entry[item.entry_id]
            if version.entry_version_id != item.entry_version_id:
                raise InvalidMemoryCitationError("projection-version")
            prepared.append(MemoryProjection(entry_version=version, searchable_text=analyze_text(version.text)))
            embed_indices.append(len(prepared) - 1)
        return await self._attach_embeddings(tuple(prepared), embed_indices)

    async def _previous_projections(self, base: Memory | None) -> dict[str, MemoryProjection]:
        if base is None:
            return {}
        reference = base.as_ref()
        cached = self._previous_projection_cache
        if cached is not None and cached[0] == reference:
            active = {item.entry_version_id for item in base.content.manifest.entries if item.state == "active"}
            if active <= cached[1].keys():
                return cached[1]
            # A commit whose outer transaction rolled back leaves this cache behind
            # while the stored revision never advanced; another writer can then reuse
            # the same reference with a different entry set, so a cached revision
            # missing an active version belongs to no stored revision.
        projections = {
            projection.entry_version.entry_version_id: projection
            for projection in await self._backend.projections(reference)
        }
        self._previous_projection_cache = (reference, projections)
        return projections

    def _cache_projections(self, committed: Memory, projections: tuple[MemoryProjection, ...]) -> None:
        self._previous_projection_cache = (
            committed.as_ref(),
            {projection.entry_version.entry_version_id: projection for projection in projections},
        )

    async def _attach_embeddings(
        self,
        projections: tuple[MemoryProjection, ...],
        embed_indices: Sequence[int],
    ) -> tuple[MemoryProjection, ...]:
        if not projections or not embed_indices or self._embedding_model is None:
            return projections
        capabilities = await self._backend.capabilities()
        profile = capabilities.embedding_profile
        if not capabilities.vector or profile is None:
            return projections
        embedding_profile = self._embedding_model.profile
        if embedding_profile != profile:
            return projections
        try:
            vectors = await self._embed_texts(
                tuple(projections[index].entry_version.text for index in embed_indices),
                profile,
            )
        except (InferenceUnavailableError, InferenceTimeoutError):
            return projections
        updated = list(projections)
        for index, vector in zip(embed_indices, vectors, strict=True):
            projection = updated[index]
            updated[index] = projection.model_copy(
                update={
                    "embedding": vector,
                    "embedding_content_hash": embedding_content_hash(
                        profile_id=profile.profile_id,
                        model=profile.model,
                        dimension=profile.dimension,
                        distance=profile.distance,
                        normalization=profile.normalization,
                        entry_content_hash=projection.entry_version.entry_content_hash,
                    ),
                }
            )
        return tuple(updated)

    async def _embed_texts(
        self,
        texts: tuple[str, ...],
        profile: EmbeddingProfile,
        *,
        query: bool = False,
    ) -> tuple[EmbeddingVector, ...]:
        embedding_model = self._embedding_model
        if embedding_model is None or embedding_model.profile != profile:
            raise CapabilityNotSupportedError("embedding-profile")
        result = await embed_query(embedding_model, texts) if query else await embedding_model.embed(texts)
        vectors = result.vectors
        if len(vectors) != len(texts):
            raise InvalidEmbeddingError("count")
        return tuple(
            canonical_embedding(
                vector,
                dimension=profile.dimension,
                normalization=profile.normalization,
            )
            for vector in vectors
        )

    @overload
    async def _canonical_base(self, memory: None) -> None: ...

    @overload
    async def _canonical_base(self, memory: Memory) -> Memory: ...

    async def _canonical_base(self, memory: Memory | None) -> Memory | None:
        if memory is None:
            return None
        exact = await self._backend.get(memory.as_ref())
        if exact != memory:
            raise InvalidMemoryCitationError("base-mismatch")
        latest = await self._backend.latest(memory.artifact_id)
        if latest != exact:
            raise RevisionConflictError(memory, latest)
        return exact

    async def _canonical_memory(self, memory: Memory) -> Memory:
        exact = await self._backend.get(memory.as_ref())
        if exact != memory:
            raise InvalidMemoryCitationError("memory-mismatch")
        return exact

    async def _canonical_operation_evidence(
        self,
        sources: Sequence[Source],
        artifacts: Sequence[Artifact[object]],
    ) -> _OperationEvidence:
        canonical_sources: list[Source] = []
        for source in sources:
            if self._source_resolver is None:
                raise InvalidMemoryEvidenceError("source-resolver")
            _append_unique(canonical_sources, await self._source_resolver.get(source))

        canonical_artifacts: list[Artifact[object]] = []
        for artifact in artifacts:
            if artifact.family == "prompt":
                raise InvalidMemoryEvidenceError("prompt-configuration")
            if self._artifact_resolver is None:
                raise InvalidMemoryEvidenceError("artifact-resolver")
            _append_unique(canonical_artifacts, await self._artifact_resolver.get(artifact))
        return _OperationEvidence(
            sources=tuple(canonical_sources),
            artifacts=tuple(canonical_artifacts),
        )

    async def _validated_entries(self, memory: Memory) -> tuple[MemoryEntryVersion, ...]:
        versions = await self._backend.entries(memory.as_ref())
        versions_by_id = {version.entry_version_id: version for version in versions}
        if len(versions_by_id) != len(versions):
            raise InvalidMemoryCitationError("duplicate-versions")

        ordered: list[MemoryEntryVersion] = []
        for item in memory.content.manifest.entries:
            version = versions_by_id.get(item.entry_version_id)
            if version is None:
                raise InvalidMemoryCitationError("missing-version")
            if version.memory_artifact_id != memory.artifact_id or version.entry_id != item.entry_id:
                raise InvalidMemoryCitationError("cross-identity")
            material = self._material_from_version(version)
            if material.content_hash != item.entry_content_hash:
                raise InvalidMemoryCitationError("hash-mismatch")
            ordered.append(version)
        return tuple(ordered)

    async def _candidates(
        self,
        mode: Literal["append", "extract"],
        entries: tuple[MemoryEntryInput, ...],
        evidence: _OperationEvidence,
        current_entries: tuple[MemoryEntryVersion, ...],
        *,
        active_version_ids: frozenset[str],
    ) -> tuple[MemoryEntryInput, ...]:
        if mode == "append":
            return entries
        if self._candidate_pipeline is None:
            raise CapabilityNotSupportedError("extract")
        bounded = tuple(entry for entry in current_entries if entry.entry_version_id in active_version_ids)
        return await self._candidate_pipeline.extract(
            MemoryCandidateRequest(
                sources=evidence.sources,
                artifacts=evidence.artifacts,
                current_entries=bounded,
            )
        )

    async def _assess_write(
        self,
        base: Memory | None,
        candidates: tuple[MemoryEntryInput, ...],
        evidence: _OperationEvidence,
        current_entries: tuple[MemoryEntryVersion, ...] | None,
    ) -> MemoryWriteAssessment | None:
        """Ask the configured gate about one candidate set; ``None`` means no gate is active."""

        if self._write_gate is None:
            return None
        projection = await self._gate_evidence(base, candidates, evidence, current_entries)
        if projection.rejection is not None:
            _log_gate_assessment(projection.rejection)
            return projection.rejection
        try:
            return await self._write_gate.assess(
                MemoryWriteGateRequest(
                    candidates=tuple(candidate.text for candidate in candidates),
                    evidence=projection.entries,
                    expected_revision=None if base is None else base.revision,
                )
            )
        except Exception:
            return MemoryWriteAssessment(
                verdict=MemoryWriteVerdict.ACCEPT,
                policy_id=self._write_gate.policy_id,
                used_fallback=True,
            )

    async def _gate_evidence(
        self,
        base: Memory | None,
        candidates: tuple[MemoryEntryInput, ...],
        evidence: _OperationEvidence,
        current_entries: tuple[MemoryEntryVersion, ...] | None,
    ) -> _GateEvidenceProjection:
        builder = _GateEvidenceBuilder(self._write_gate_policy_id(), [])
        for candidate in await self._gate_candidate_evidence(base, candidates, evidence, current_entries):
            for entry in await self._candidate_gate_evidence(candidate):
                if rejection := builder.append(entry):
                    return _GateEvidenceProjection(tuple(builder.entries), rejection)
        return builder.projection()

    async def _gate_candidate_evidence(
        self,
        base: Memory | None,
        candidates: tuple[MemoryEntryInput, ...],
        evidence: _OperationEvidence,
        current_entries: tuple[MemoryEntryVersion, ...] | None,
    ) -> tuple[_GateCandidateEvidence, ...]:
        current_by_entry = {} if current_entries is None else {entry.entry_id: entry for entry in current_entries}
        targeted: set[str] = set()
        resolved: list[_GateCandidateEvidence] = []
        for index, candidate in enumerate(candidates, start=1):
            previous = None
            if candidate.entry is not None:
                _, previous = await self._claim_revision_target(candidate, base, current_by_entry, targeted)
            material = await self._material_from_candidate(
                candidate,
                evidence.sources,
                evidence.artifacts,
                previous=previous,
            )
            resolved.append(_GateCandidateEvidence(index=index, material=material))
        return tuple(resolved)

    async def _candidate_gate_evidence(self, candidate: _GateCandidateEvidence) -> tuple[_GateEvidenceEntry, ...]:
        entries = [
            await self._source_ref_gate_evidence(candidate.index, source) for source in candidate.material.sources
        ]
        entries.extend([
            await self._artifact_ref_gate_evidence(candidate.index, artifact)
            for artifact in candidate.material.artifacts
        ])
        return tuple(entries)

    def _source_gate_evidence(self, candidate_index: int, source: Source) -> _GateEvidenceEntry:
        ref = self._source_refs((source,))[0]
        identity = _candidate_gate_identity(candidate_index, f"source:{ref.source_type}:{ref.source_id}")
        content = _source_gate_content(source, self._source_resolver)
        if isinstance(content, str) and content.strip():
            return _bounded_gate_evidence(identity, content)
        return _incomplete_gate_evidence(identity)

    @staticmethod
    def _artifact_gate_evidence(candidate_index: int, artifact: Artifact[object]) -> _GateEvidenceEntry:
        ref = artifact.as_ref()
        return _bounded_gate_evidence(
            _candidate_gate_identity(candidate_index, f"artifact:{ref.family}:{ref.artifact_id}@{ref.revision}"),
            _artifact_gate_content(artifact),
        )

    async def _source_ref_gate_evidence(self, candidate_index: int, ref: SourceRef) -> _GateEvidenceEntry:
        identity = _candidate_gate_identity(candidate_index, f"source:{ref.source_type}:{ref.source_id}")
        if self._source_resolver is None:
            return _incomplete_gate_evidence(identity)
        try:
            return self._source_gate_evidence(candidate_index, await self._source_resolver.get_ref(ref))
        except Exception:
            return _incomplete_gate_evidence(identity)

    async def _artifact_ref_gate_evidence(self, candidate_index: int, ref: ArtifactRef) -> _GateEvidenceEntry:
        identity = _candidate_gate_identity(candidate_index, f"artifact:{ref.family}:{ref.artifact_id}@{ref.revision}")
        if self._artifact_resolver is None:
            return _incomplete_gate_evidence(identity)
        try:
            return self._artifact_gate_evidence(candidate_index, await self._artifact_resolver.get_ref(ref))
        except Exception:
            return _incomplete_gate_evidence(identity)

    def _write_gate_policy_id(self) -> str:
        if self._write_gate is not None:
            return self._write_gate.policy_id
        return "memory.write-gate"

    async def _prepare_commit(
        self,
        *,
        base: Memory | None,
        candidates: tuple[MemoryEntryInput, ...],
        evidence: _OperationEvidence,
        current_entries: tuple[MemoryEntryVersion, ...] | None,
        flagged_reason: str | None = None,
    ) -> MemoryCommit | None:
        memory_id = base.artifact_id if base is not None else self._new_id("memory")
        next_revision = 1 if base is None else base.revision + 1
        manifest = {} if base is None else {entry.entry_id: entry for entry in base.content.manifest.entries}
        current_by_entry = {} if current_entries is None else {entry.entry_id: entry for entry in current_entries}
        new_versions: list[MemoryEntryVersion] = []
        changes: list[MemoryChange] = []
        targeted: set[str] = set()
        # The manifest records each active entry's validated content hash, so exact
        # duplicate detection compares hashes; rebuilding every body here would cost
        # one material per entry to answer the same question.
        new_content: set[str] = {item.entry_content_hash for item in manifest.values() if item.state == "active"}

        for candidate in candidates:
            if candidate.entry is None:
                material = await self._material_from_candidate(candidate, evidence.sources, evidence.artifacts)
                if material.content_hash in new_content:
                    continue
                new_content.add(material.content_hash)
                entry_id = self._new_id("entry")
                if entry_id in manifest:
                    raise _InvalidMemoryOperationError("id-collision")
                version = self._new_entry_version(
                    memory_id=memory_id,
                    entry_id=entry_id,
                    previous=None,
                    material=material,
                    created_in_revision=next_revision,
                )
                manifest[entry_id] = _manifest_entry(version, state="active")
                current_by_entry[entry_id] = version
                new_versions.append(version)
                changes.append(
                    MemoryChange(
                        op="add",
                        entry_id=entry_id,
                        from_entry_version_id=None,
                        to_entry_version_id=version.entry_version_id,
                        reason=_annotate_reason(candidate.reason, flagged_reason),
                    )
                )
                continue

            entry_id, previous = await self._claim_revision_target(candidate, base, current_by_entry, targeted)
            item = manifest.get(entry_id)
            if item is None:
                raise MemoryEntryNotFoundError(entry_id)
            if item.state == "inactive":
                raise MemoryEntryInactiveError(entry_id)
            material = await self._material_from_candidate(
                candidate,
                evidence.sources,
                evidence.artifacts,
                previous=previous,
            )
            previous_material = self._material_from_version(previous)
            if (
                material.content_hash == previous_material.content_hash
                and material.content_bytes == previous_material.content_bytes
            ):
                continue
            version = self._new_entry_version(
                memory_id=memory_id,
                entry_id=entry_id,
                previous=previous,
                material=material,
                created_in_revision=next_revision,
            )
            manifest[entry_id] = _manifest_entry(version, state="active")
            current_by_entry[entry_id] = version
            new_versions.append(version)
            changes.append(
                MemoryChange(
                    op="revise",
                    entry_id=entry_id,
                    from_entry_version_id=previous.entry_version_id,
                    to_entry_version_id=version.entry_version_id,
                    reason=_annotate_reason(candidate.reason, flagged_reason),
                )
            )

        if not changes:
            return None

        sorted_manifest = tuple(sorted(manifest.values(), key=lambda item: item.entry_id.encode("utf-8")))
        sorted_changes = tuple(sorted(changes, key=lambda change: change.entry_id.encode("utf-8")))
        content = MemoryContent(manifest=MemoryManifest(entries=sorted_manifest), changes=sorted_changes)
        content_bytes = memory_content_bytes(content)
        self._require_capacity(
            base,
            content,
            growth=frozenset(dimension for dimension, _ in self._capacity_limits()),
            content_bytes=content_bytes,
        )
        memory = Memory(
            artifact_id=memory_id,
            revision=next_revision,
            content=content,
            lineage=ArtifactLineage(
                sources=self._source_refs(evidence.sources),
                artifacts=tuple(artifact.as_ref() for artifact in evidence.artifacts) + _extraction_prompt_refs(),
            ),
        )
        projections = await self._prepare_projections(
            base=base,
            manifest_entries=sorted_manifest,
            versions_by_entry=current_by_entry,
            changed_version_ids=frozenset(version.entry_version_id for version in new_versions),
        )
        return MemoryCommit(
            base=base,
            memory=memory,
            content_hash=sha256(content_bytes).hexdigest(),
            entry_versions=tuple(new_versions),
            projections=projections,
        )

    async def _claim_revision_target(
        self,
        candidate: MemoryEntryInput,
        base: Memory | None,
        current_by_entry: dict[str, MemoryEntryVersion],
        targeted: set[str],
    ) -> tuple[str, MemoryEntryVersion]:
        entry = candidate.entry
        if entry is None:
            raise InvalidMemoryCitationError("entry-missing")
        entry_id = validate_identifier(entry.entry_id)
        if entry_id in targeted:
            raise _InvalidMemoryOperationError("duplicate-target")
        previous = current_by_entry.get(entry_id)
        if previous is None and base is not None:
            # A revise needs the exact version it targets; the common append path
            # never loads the current entry set at all.
            current_by_entry.update({value.entry_id: value for value in await self._validated_entries(base)})
            previous = current_by_entry.get(entry_id)
        if previous is None:
            raise MemoryEntryNotFoundError(entry_id)
        if entry != previous:
            raise InvalidMemoryCitationError("entry-mismatch")
        targeted.add(entry_id)
        return entry_id, previous

    async def _material_from_candidate(
        self,
        candidate: MemoryEntryInput,
        allowed_sources: Sequence[Source],
        allowed_artifacts: Sequence[Artifact[object]],
        *,
        previous: MemoryEntryVersion | None = None,
    ) -> _EntryMaterial:
        previous_artifacts = () if previous is None else previous.artifacts
        candidate_sources = await self._canonical_candidate_sources(candidate.sources, allowed_sources)
        candidate_source_refs = self._source_refs(candidate_sources)
        candidate_artifacts = await self._canonical_candidate_artifacts(
            candidate.artifacts,
            allowed_artifacts,
            previous_artifacts,
        )
        if previous is None:
            sources = candidate_source_refs
            artifacts = candidate_artifacts
        else:
            # Revises retain predecessor evidence and add current candidate evidence.
            sources = (*previous.sources, *candidate_source_refs)
            artifacts = (*previous.artifacts, *candidate_artifacts)
        try:
            return self._entry_material(
                kind=candidate.kind,
                text=candidate.text,
                sources=sources,
                artifacts=artifacts,
            )
        except (TypeError, ValueError) as error:
            raise InvalidMemoryCandidateError(
                "canonical",
                str(error),
                canonical_code=canonical_error_code(error),
            ) from error

    async def _canonical_candidate_sources(
        self,
        values: Sequence[Source],
        allowed: Sequence[Source],
    ) -> tuple[Source, ...]:
        result: list[Source] = []
        for value in values:
            canonical = value if self._source_resolver is None else await self._source_resolver.get(value)
            match = _equal_member(canonical, allowed)
            if match is None:
                raise InvalidMemoryEvidenceError("source-outside")
            _append_unique(result, match)
        return tuple(result)

    async def _canonical_candidate_artifacts(
        self,
        values: Sequence[Artifact[object]],
        allowed: Sequence[Artifact[object]],
        previous: Sequence[ArtifactRef],
    ) -> tuple[ArtifactRef, ...]:
        result: list[ArtifactRef] = []
        allowed_refs = tuple(artifact.as_ref() for artifact in allowed)
        for value in values:
            canonical = _matching_allowed_artifact(value, allowed)
            if canonical is None:
                canonical = value if self._artifact_resolver is None else await self._artifact_resolver.get(value)
            reference = canonical.as_ref()
            if reference not in (*allowed_refs, *previous):
                raise InvalidMemoryEvidenceError("artifact-outside")
            if reference not in result:
                result.append(reference)
        return tuple(result)

    def _material_from_version(self, version: MemoryEntryVersion) -> _EntryMaterial:
        return self._entry_material(
            kind=version.kind,
            text=version.text,
            sources=version.sources,
            artifacts=version.artifacts,
        )

    def _entry_material(
        self,
        *,
        kind: str,
        text: str,
        sources: Sequence[SourceRef],
        artifacts: Sequence[ArtifactRef],
    ) -> _EntryMaterial:
        normalized_kind = normalize_kind(kind)
        normalized_text = normalize_text(text)
        canonical_sources = _canonical_source_refs(sources)
        canonical_artifacts = _canonical_artifact_refs(artifacts)
        source_refs = tuple(source.model_dump(mode="json") for source in canonical_sources)
        artifact_refs = tuple(artifact.model_dump(mode="json") for artifact in canonical_artifacts)
        content_bytes = entry_content_bytes(
            kind=normalized_kind,
            text=normalized_text,
            source_refs=source_refs,
            artifact_refs=artifact_refs,
        )
        return _EntryMaterial(
            kind=normalized_kind,
            text=normalized_text,
            sources=canonical_sources,
            artifacts=canonical_artifacts,
            content_bytes=content_bytes,
            content_hash=entry_content_hash(
                kind=normalized_kind,
                text=normalized_text,
                source_refs=source_refs,
                artifact_refs=artifact_refs,
            ),
        )

    def _source_refs(self, sources: Sequence[Source]) -> tuple[SourceRef, ...]:
        if not sources:
            return ()
        if self._source_resolver is None:
            raise InvalidMemoryEvidenceError("source-adapter")
        keyed: dict[bytes, SourceRef] = {}
        for source in sources:
            try:
                reference = self._source_resolver.as_ref(source)
            except (KeyError, LookupError, TypeError, ValueError):
                raise InvalidMemoryEvidenceError("source-adapter") from None
            keyed.setdefault(canonical_json(reference.model_dump(mode="json")), reference)
        return tuple(keyed[key] for key in sorted(keyed))

    def _new_entry_version(
        self,
        *,
        memory_id: str,
        entry_id: str,
        previous: MemoryEntryVersion | None,
        material: _EntryMaterial,
        created_in_revision: int,
    ) -> MemoryEntryVersion:
        return MemoryEntryVersion(
            memory_artifact_id=memory_id,
            entry_id=entry_id,
            entry_version_id=self._new_id("version"),
            version=1 if previous is None else previous.version + 1,
            previous_version_id=None if previous is None else previous.entry_version_id,
            kind=material.kind,
            text=material.text,
            sources=material.sources,
            artifacts=material.artifacts,
            entry_content_hash=material.content_hash,
            created_in_revision=created_in_revision,
        )

    def _new_id(self, kind: str) -> str:
        return validate_identifier(self._id_factory(kind))


def _select_remember_mode(
    mode: MemoryRememberMode,
    *,
    has_entries: bool,
    has_evidence: bool,
) -> Literal["append", "extract"]:
    if mode == "append":
        if not has_entries:
            raise _InvalidMemoryOperationError("append-entries")
        return "append"
    if mode == "extract":
        if has_entries or not has_evidence:
            raise _InvalidMemoryOperationError("extract-evidence")
        return "extract"
    if mode != "auto":
        raise InvalidMemoryCandidateError("remember-mode", mode)
    if has_entries:
        return "append"
    if has_evidence:
        return "extract"
    raise _InvalidMemoryOperationError("no-work")


def _manifest_entry(version: MemoryEntryVersion, *, state: Literal["active", "inactive"]) -> MemoryManifestEntry:
    return MemoryManifestEntry(
        entry_id=version.entry_id,
        entry_version_id=version.entry_version_id,
        entry_content_hash=version.entry_content_hash,
        state=state,
    )


def _raise_if_write_held(plan: MemoryWritePlan) -> None:
    decision = plan.decision
    if decision is None or decision.verdict is not MemoryWriteVerdict.HOLD:
        return
    code = "unspecified" if decision.code is None else decision.code.value
    raise MemoryWriteRejectedError(code, decision.reason)


def _bounded_gate_evidence(identity: str, content: str) -> _GateEvidenceEntry:
    normalized = normalize_text(content)
    return _GateEvidenceEntry(
        text=f"{identity}\n{normalized[:_GATE_EVIDENCE_TEXT_LIMIT]}",
        complete=len(normalized) <= _GATE_EVIDENCE_TEXT_LIMIT,
    )


def _incomplete_gate_evidence(identity: str) -> _GateEvidenceEntry:
    return _GateEvidenceEntry(text=identity, complete=False)


def _candidate_gate_identity(candidate_index: int, identity: str) -> str:
    return f"candidate:{candidate_index} {identity}"


def _source_gate_content(source: Source, resolver: _SourceResolver | None) -> str | None:
    content = getattr(source, "content", None)
    if isinstance(content, str):
        return content
    if isinstance(source, SourceObservation):
        try:
            evidence = TextEvidence.model_validate(source.projection(TEXT_EVIDENCE_PROJECTION_KEY))
        except Exception:
            return None
        return evidence.content
    if resolver is not None:
        try:
            evidence = TextEvidence.model_validate(resolver.project(source, TEXT_EVIDENCE_PROJECTION_KEY))
        except Exception:
            return None
        return evidence.content
    return None


def _log_gate_assessment(assessment: MemoryWriteAssessment) -> None:
    event = {
        MemoryWriteVerdict.HOLD: "memory.write-gate.hold",
        MemoryWriteVerdict.FLAG: "memory.write-gate.flag",
    }.get(assessment.verdict, "memory.write-gate.assess")
    log_safely(
        logger,
        logging.INFO,
        "Memory write gate assessed a pending write",
        extra={
            "event": event,
            "decision_kind": "memory.write-gate",
            "policy_id": assessment.policy_id,
            "verdict": assessment.verdict.value,
            "code": None if assessment.code is None else assessment.code.value,
            "used_fallback": assessment.used_fallback,
        },
    )


def _artifact_gate_content(artifact: Artifact[object]) -> str:
    content = artifact.content
    if isinstance(content, BaseModel):
        return content.model_dump_json()
    return str(content)


def _matching_allowed_artifact(
    value: Artifact[object],
    allowed: Sequence[Artifact[object]],
) -> Artifact[object] | None:
    reference = value.as_ref()
    for artifact in allowed:
        if artifact.as_ref() == reference:
            return artifact
    # Pydantic validates MemoryEntryInput artifacts through the generic Artifact[object]
    # annotation, which strips the concrete subclass family. Fall back to the operation's
    # canonical evidence set when the revision identity and body match exactly.
    if value.family != Artifact.family:
        return None
    matches = [
        artifact
        for artifact in allowed
        if artifact.artifact_id == value.artifact_id
        and artifact.revision == value.revision
        and artifact.content == value.content
    ]
    return matches[0] if len(matches) == 1 else None


def _canonical_source_refs(values: Sequence[SourceRef]) -> tuple[SourceRef, ...]:
    keyed = {canonical_json(value.model_dump(mode="json")): value for value in values}
    return tuple(keyed[key] for key in sorted(keyed))


def _canonical_artifact_refs(values: Sequence[ArtifactRef]) -> tuple[ArtifactRef, ...]:
    keyed = {canonical_json(value.model_dump(mode="json")): value for value in values}
    return tuple(keyed[key] for key in sorted(keyed))


def _is_canonical_version(version: MemoryEntryVersion, material: _EntryMaterial) -> bool:
    return (
        version.kind == material.kind
        and version.text == material.text
        and version.sources == material.sources
        and version.artifacts == material.artifacts
    )


def _append_unique(values: list[ValueT], value: ValueT) -> None:
    if not any(current == value for current in values):
        values.append(value)


def _equal_member(value: ValueT, values: Sequence[ValueT]) -> ValueT | None:
    return next((current for current in values if current == value), None)


def _default_id(kind: str) -> str:
    prefixes = {"memory": "mem_art", "entry": "mem_ent", "version": "mem_ver"}
    try:
        prefix = prefixes[kind]
    except KeyError:
        raise InvalidMemoryCandidateError("identity-kind", kind) from None
    return f"{prefix}_{uuid4().hex}"
