# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Atomic Topic Memory publication and bounded current-head retrieval."""

from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import and_, delete, func, insert, or_, select, update
from sqlalchemy.dialects.mysql import insert as mysql_insert
from sqlalchemy.dialects.sqlite import insert as sqlite_insert
from sqlalchemy.ext.asyncio import AsyncConnection

from powercontext.artifacts import ArtifactAddress, ArtifactRef
from powercontext.builtin.artifacts.memory import EmbeddingProfile
from powercontext.builtin.artifacts.memory.canonical import canonical_embedding
from powercontext.builtin.artifacts.search import AdmissionCounts, AdmissionFloor, analyze_fts_query, analyze_text
from powercontext.builtin.artifacts.topic_memory import (
    MAX_TOPIC_MEMORY_CHANNEL_CANDIDATES,
    MAX_TOPIC_MEMORY_QUERY_LENGTH,
    MAX_TOPIC_MEMORY_QUERY_TERMS,
    MAX_TOPIC_MEMORY_SEARCH_LIMIT,
    PublishedTopicMemory,
    TopicMemory,
    TopicMemoryBrowseCursor,
    TopicMemoryCapabilityError,
    TopicMemoryCurrentItem,
    TopicMemoryDraft,
    TopicMemoryProjection,
    TopicMemoryProjectionError,
    TopicMemorySearchMode,
    TopicMemorySearchRequest,
    TopicMemorySearchResult,
    TopicMemoryStorageInvariantError,
    TopicMemoryUsedSearchMode,
    chunk_topic_memory_detail,
)
from powercontext.builtin.artifacts.topic_memory.fusion import _fuse_topic_memory_rankings
from powercontext.builtin.persistence.artifacts import ArtifactRepository
from powercontext.builtin.persistence.errors import InvalidRepositoryArgumentError
from powercontext.builtin.persistence.supervision import database_utc_now
from powercontext.builtin.persistence.tables import (
    ARTIFACT_HEADS_TABLE,
    ARTIFACTS_TABLE,
    TOPIC_MEMORY_ACTIVE_CHUNKS_TABLE,
    TOPIC_MEMORY_ACTIVE_TOPICS_TABLE,
    TOPIC_MEMORY_RETRIEVAL_SHAPE_TABLE,
    TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE,
)
from powercontext.builtin.persistence.tags import tag_predicate
from powercontext.builtin.persistence.topic_memory_index import (
    NoTopicMemoryIndex,
    TopicMemoryIndex,
    topic_memory_embedding_profile_fingerprint,
)
from powercontext.builtin.tags import TagFilter


class TopicMemoryRepository:
    """Store complete searchable Topic Revisions through one caller transaction."""

    def __init__(
        self,
        *,
        artifacts: ArtifactRepository | None = None,
        index: TopicMemoryIndex | None = None,
    ) -> None:
        self.artifacts = ArtifactRepository((TopicMemory,)) if artifacts is None else artifacts
        self.index = NoTopicMemoryIndex() if index is None else index

    async def initialize(self, connection: AsyncConnection, /, *, configure_retrieval_shape: bool = True) -> None:
        """Initialize indexes and reject incomplete historical Topic projections.

        Only deployment startup may configure an empty store. Workers must
        reuse an existing shape and fail closed if it is absent or mismatched.
        """

        missing_publication = (
            await connection.execute(
                select(
                    ARTIFACTS_TABLE.c.scope_id,
                    ARTIFACTS_TABLE.c.artifact_id,
                    ARTIFACTS_TABLE.c.revision,
                )
                .outerjoin(
                    TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE,
                    (TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE.c.scope_id == ARTIFACTS_TABLE.c.scope_id)
                    & (TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE.c.family == ARTIFACTS_TABLE.c.family)
                    & (TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE.c.artifact_id == ARTIFACTS_TABLE.c.artifact_id)
                    & (TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE.c.revision == ARTIFACTS_TABLE.c.revision),
                )
                .where(
                    ARTIFACTS_TABLE.c.family == TopicMemory.family,
                    TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE.c.artifact_id.is_(None),
                )
                .limit(1)
            )
        ).one_or_none()
        if missing_publication is not None:
            raise TopicMemoryStorageInvariantError("missing-publication", tuple(missing_publication))

        if configure_retrieval_shape:
            await self._ensure_retrieval_shape(connection, allow_empty_change=True)
        else:
            await self._check_retrieval_shape(connection)
        await self.index.initialize(connection)

        orphan_active = (
            await connection.execute(
                select(
                    TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.scope_id,
                    TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.artifact_id,
                    TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.revision,
                )
                .outerjoin(
                    ARTIFACT_HEADS_TABLE,
                    (ARTIFACT_HEADS_TABLE.c.scope_id == TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.scope_id)
                    & (ARTIFACT_HEADS_TABLE.c.family == TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.family)
                    & (ARTIFACT_HEADS_TABLE.c.artifact_id == TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.artifact_id)
                    & (ARTIFACT_HEADS_TABLE.c.revision == TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.revision),
                )
                .where(ARTIFACT_HEADS_TABLE.c.artifact_id.is_(None))
                .limit(1)
            )
        ).one_or_none()
        if orphan_active is not None:
            raise TopicMemoryStorageInvariantError("active-topic-not-head", tuple(orphan_active))

        orphan_chunk = (
            await connection.execute(
                select(
                    TOPIC_MEMORY_ACTIVE_CHUNKS_TABLE.c.scope_id,
                    TOPIC_MEMORY_ACTIVE_CHUNKS_TABLE.c.artifact_id,
                    TOPIC_MEMORY_ACTIVE_CHUNKS_TABLE.c.revision,
                    TOPIC_MEMORY_ACTIVE_CHUNKS_TABLE.c.chunk_ordinal,
                )
                .outerjoin(
                    TOPIC_MEMORY_ACTIVE_TOPICS_TABLE,
                    (TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.scope_id == TOPIC_MEMORY_ACTIVE_CHUNKS_TABLE.c.scope_id)
                    & (TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.family == TOPIC_MEMORY_ACTIVE_CHUNKS_TABLE.c.family)
                    & (TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.artifact_id == TOPIC_MEMORY_ACTIVE_CHUNKS_TABLE.c.artifact_id)
                    & (TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.revision == TOPIC_MEMORY_ACTIVE_CHUNKS_TABLE.c.revision),
                )
                .where(TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.artifact_id.is_(None))
                .limit(1)
            )
        ).one_or_none()
        if orphan_chunk is not None:
            raise TopicMemoryStorageInvariantError("active-chunk-not-head", tuple(orphan_chunk))

        # Check each Head and its chunks in the same statement snapshot. A
        # Worker may use READ COMMITTED (or SQLite legacy SELECT mode), where a
        # later query could otherwise see an already-replaced active Revision.
        chunk_count = (
            select(func.count())
            .select_from(TOPIC_MEMORY_ACTIVE_CHUNKS_TABLE)
            .where(
                TOPIC_MEMORY_ACTIVE_CHUNKS_TABLE.c.scope_id == ARTIFACT_HEADS_TABLE.c.scope_id,
                TOPIC_MEMORY_ACTIVE_CHUNKS_TABLE.c.family == ARTIFACT_HEADS_TABLE.c.family,
                TOPIC_MEMORY_ACTIVE_CHUNKS_TABLE.c.artifact_id == ARTIFACT_HEADS_TABLE.c.artifact_id,
                TOPIC_MEMORY_ACTIVE_CHUNKS_TABLE.c.revision == ARTIFACT_HEADS_TABLE.c.revision,
            )
            .correlate(ARTIFACT_HEADS_TABLE)
            .scalar_subquery()
        )
        invalid_head = (
            (
                await connection.execute(
                    select(
                        ARTIFACT_HEADS_TABLE.c.scope_id,
                        ARTIFACT_HEADS_TABLE.c.artifact_id,
                        ARTIFACT_HEADS_TABLE.c.revision,
                        TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.revision.label("active_revision"),
                    )
                    .outerjoin(
                        TOPIC_MEMORY_ACTIVE_TOPICS_TABLE,
                        (TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.scope_id == ARTIFACT_HEADS_TABLE.c.scope_id)
                        & (TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.family == ARTIFACT_HEADS_TABLE.c.family)
                        & (TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.artifact_id == ARTIFACT_HEADS_TABLE.c.artifact_id),
                    )
                    .where(
                        ARTIFACT_HEADS_TABLE.c.family == TopicMemory.family,
                        or_(
                            TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.revision.is_(None),
                            TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.revision != ARTIFACT_HEADS_TABLE.c.revision,
                            chunk_count == 0,
                        ),
                    )
                    .limit(1)
                )
            )
            .mappings()
            .one_or_none()
        )
        if invalid_head is not None:
            row = invalid_head
            ref = ArtifactRef(
                family=TopicMemory.family,
                artifact_id=str(row["artifact_id"]),
                revision=int(row["revision"]),
            )
            if row["active_revision"] is None or int(row["active_revision"]) != ref.revision:
                raise TopicMemoryStorageInvariantError("head-not-active", (str(row["scope_id"]), ref))
            raise TopicMemoryStorageInvariantError("missing-active-chunks", (str(row["scope_id"]), ref))

        await self.index.validate_current(connection)

        if not configure_retrieval_shape:
            await self._check_retrieval_shape(connection)

    async def publish_create(
        self,
        connection: AsyncConnection,
        scope_id: str,
        artifact_id: str,
        draft: TopicMemoryDraft,
        projection: TopicMemoryProjection,
        /,
    ) -> PublishedTopicMemory:
        """Create Revision 1 and activate every configured channel atomically."""

        projection = self._validate_projection(draft, projection)
        await self._ensure_retrieval_shape(connection)
        topic = await self.artifacts.create(connection, scope_id, artifact_id, draft)
        if not isinstance(topic, TopicMemory):
            raise TopicMemoryStorageInvariantError("artifact-type", topic.as_ref())
        published_at = await self._activate(connection, scope_id, topic, projection)
        return PublishedTopicMemory(
            topic=topic,
            published_at=_aware_utc(published_at),
            is_current=True,
            current_artifact=topic.as_ref(),
        )

    async def publish_revision(
        self,
        connection: AsyncConnection,
        scope_id: str,
        current: TopicMemory,
        draft: TopicMemoryDraft,
        projection: TopicMemoryProjection,
        /,
    ) -> PublishedTopicMemory:
        """CAS the current Head and atomically replace its complete active projection."""

        projection = self._validate_projection(draft, projection)
        await self._ensure_retrieval_shape(connection)
        previous = current.as_ref()
        if previous not in draft.artifacts:
            draft = draft.model_copy(update={"artifacts": (previous, *draft.artifacts)})
        topic = await self.artifacts.revise(connection, scope_id, current, draft)
        if not isinstance(topic, TopicMemory):
            raise TopicMemoryStorageInvariantError("artifact-type", topic.as_ref())
        published_at = await self._activate(connection, scope_id, topic, projection)
        return PublishedTopicMemory(
            topic=topic,
            published_at=_aware_utc(published_at),
            is_current=True,
            current_artifact=topic.as_ref(),
        )

    async def publish_copy(
        self,
        connection: AsyncConnection,
        target_scope_id: str,
        target_artifact_id: str,
        source_address: ArtifactAddress,
        content_digest: str,
        projection: TopicMemoryProjection,
    ) -> TopicMemory:
        """Copy an exact published revision and activate its complete target state."""

        source = (await self.get_exact(connection, source_address.scope_id, source_address.artifact)).topic
        projection = self._validate_projection(TopicMemoryDraft(content=source.content), projection)
        topic = await self.artifacts.copy_exact(
            connection, target_scope_id, target_artifact_id, source_address, source, content_digest
        )
        if not isinstance(topic, TopicMemory):
            raise TopicMemoryStorageInvariantError("artifact-type", topic.as_ref())
        await self._activate(connection, target_scope_id, topic, projection)
        return topic

    async def get_exact(
        self,
        connection: AsyncConnection,
        scope_id: str,
        ref: ArtifactRef,
        /,
    ) -> PublishedTopicMemory:
        """Read one exact immutable Revision even after its active Head changes."""

        if ref.family != TopicMemory.family:
            raise InvalidRepositoryArgumentError("artifact_ref", "must reference topic-memory")
        await self._check_retrieval_shape(connection)
        topic = await self.artifacts.get(connection, scope_id, ref)
        if not isinstance(topic, TopicMemory):
            raise TopicMemoryStorageInvariantError("artifact-type", ref)
        published_at = await connection.scalar(
            select(TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE.c.published_at).where(
                TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE.c.scope_id == scope_id,
                TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE.c.family == TopicMemory.family,
                TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE.c.artifact_id == ref.artifact_id,
                TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE.c.revision == ref.revision,
            )
        )
        if not isinstance(published_at, datetime):
            raise TopicMemoryStorageInvariantError("missing-publication", (scope_id, ref))
        active_revision = await connection.scalar(
            select(TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.revision).where(
                TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.scope_id == scope_id,
                TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.family == TopicMemory.family,
                TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.artifact_id == ref.artifact_id,
            )
        )
        if active_revision is None:
            raise TopicMemoryStorageInvariantError("missing-active-head", (scope_id, ref.artifact_id))
        current = ArtifactRef(family=TopicMemory.family, artifact_id=ref.artifact_id, revision=int(active_revision))
        await self._check_retrieval_shape(connection)
        return PublishedTopicMemory(
            topic=topic,
            published_at=_aware_utc(published_at),
            is_current=current == ref,
            current_artifact=current,
        )

    async def browse_current(
        self,
        connection: AsyncConnection,
        scope_id: str,
        /,
        *,
        limit: int,
        after: TopicMemoryBrowseCursor | None = None,
        tag_filter: TagFilter | None = None,
    ) -> tuple[TopicMemoryCurrentItem, ...]:
        """Return an exclusive, bounded current-head page in stable publication order."""

        if not 1 <= limit <= 100:
            raise InvalidRepositoryArgumentError("limit", "must be between 1 and 100")
        await self._check_retrieval_shape(connection)
        statement = (
            select(
                TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.artifact_id,
                TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.revision,
                TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.title,
                TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.summary,
                TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.source_count,
                TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE.c.published_at,
            )
            .join(
                TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE,
                (TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE.c.scope_id == TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.scope_id)
                & (TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE.c.family == TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.family)
                & (
                    TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE.c.artifact_id
                    == TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.artifact_id
                )
                & (TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE.c.revision == TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.revision),
            )
            .join(
                ARTIFACT_HEADS_TABLE,
                (ARTIFACT_HEADS_TABLE.c.scope_id == TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.scope_id)
                & (ARTIFACT_HEADS_TABLE.c.family == TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.family)
                & (ARTIFACT_HEADS_TABLE.c.artifact_id == TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.artifact_id)
                & (ARTIFACT_HEADS_TABLE.c.revision == TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.revision),
            )
            .where(
                TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.scope_id == scope_id,
                TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.family == TopicMemory.family,
            )
        )
        if tag_filter is not None:
            statement = statement.where(
                tag_predicate(
                    scope_id,
                    TopicMemory.family,
                    TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.artifact_id,
                    "artifact",
                    TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.artifact_id,
                    tag_filter,
                )
            )
        if after is not None:
            boundary = _stored_utc(after.published_at)
            statement = statement.where(
                or_(
                    TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE.c.published_at < boundary,
                    and_(
                        TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE.c.published_at == boundary,
                        TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.artifact_id > after.artifact_id,
                    ),
                    and_(
                        TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE.c.published_at == boundary,
                        TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.artifact_id == after.artifact_id,
                        TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.revision < after.revision,
                    ),
                )
            )
        rows = (
            await connection.execute(
                statement.order_by(
                    TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE.c.published_at.desc(),
                    TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.artifact_id,
                    TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.revision.desc(),
                ).limit(limit)
            )
        ).mappings()
        await self._check_retrieval_shape(connection)
        return tuple(
            TopicMemoryCurrentItem(
                artifact_ref=ArtifactRef(
                    family=TopicMemory.family,
                    artifact_id=str(row["artifact_id"]),
                    revision=int(row["revision"]),
                ),
                title=str(row["title"]),
                summary=str(row["summary"]),
                published_at=_aware_utc(row["published_at"]),
                source_count=int(row["source_count"]),
            )
            for row in rows
        )

    async def search(
        self,
        connection: AsyncConnection,
        scope_id: str,
        query: str,
        /,
        *,
        limit: int,
        mode: TopicMemorySearchMode = "auto",
        query_vector: tuple[float, ...] | None = None,
        embedding_profile: EmbeddingProfile | None = None,
        admission: AdmissionFloor | None = None,
    ) -> TopicMemorySearchResult:
        """Search current complete projections and fuse two or four logical channels.

        ``admission=None`` applies the historical fusion-time thresholds bit for bit.
        """

        if not 1 <= limit <= MAX_TOPIC_MEMORY_SEARCH_LIMIT:
            raise InvalidRepositoryArgumentError(
                "limit",
                f"must be between 1 and {MAX_TOPIC_MEMORY_SEARCH_LIMIT}",
            )
        if query != query.strip() or not query:
            raise InvalidRepositoryArgumentError("query", "must be a non-empty trimmed string")
        if len(query) > MAX_TOPIC_MEMORY_QUERY_LENGTH:
            raise InvalidRepositoryArgumentError(
                "query",
                f"must contain at most {MAX_TOPIC_MEMORY_QUERY_LENGTH} characters",
            )
        analyzed = analyze_text(query)
        used_mode = self._select_mode(mode, query_vector, embedding_profile)
        query_terms = tuple(sorted(set(analyzed.split())))
        if used_mode in {"fts", "hybrid"} and len(query_terms) > MAX_TOPIC_MEMORY_QUERY_TERMS:
            raise InvalidRepositoryArgumentError(
                "query",
                f"must contain at most {MAX_TOPIC_MEMORY_QUERY_TERMS} distinct Analyzer terms",
            )
        query_vector = self._canonical_query_vector(used_mode, query_vector)
        await self._check_retrieval_shape(connection)
        analyzed = analyze_fts_query(query)
        query_terms = tuple(sorted(set(analyzed.split())))
        if not analyzed and used_mode == "fts":
            return TopicMemorySearchResult(mode=used_mode, hits=())
        request = TopicMemorySearchRequest(
            query=query,
            analyzed_query=" ".join(query_terms),
            candidate_limit=min(MAX_TOPIC_MEMORY_CHANNEL_CANDIDATES, max(limit * 4, 32)),
            mode=used_mode,
            query_vector=query_vector,
            embedding_profile=embedding_profile,
            admission=admission,
        )
        channels = await self.index.search(connection, scope_id, request)
        await self._check_retrieval_shape(connection)
        outcome = _fuse_topic_memory_rankings(query, channels, limit, mode=used_mode, admission=admission)
        return TopicMemorySearchResult(
            mode=used_mode,
            hits=outcome.hits,
            admission=AdmissionCounts(
                family=TopicMemory.family,
                scope_id=scope_id,
                retrieved=outcome.retrieved,
                admitted=outcome.admitted,
                rejected=outcome.rejected,
            ),
        )

    async def _activate(
        self,
        connection: AsyncConnection,
        scope_id: str,
        topic: TopicMemory,
        projection: TopicMemoryProjection,
    ) -> datetime:
        published_at = await database_utc_now(connection)
        ref = topic.as_ref()
        await connection.execute(
            insert(TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE).values(
                scope_id=scope_id,
                family=TopicMemory.family,
                artifact_id=ref.artifact_id,
                revision=ref.revision,
                published_at=published_at,
            )
        )
        await self.index.replace(connection, scope_id, ref, projection)
        await connection.execute(
            delete(TOPIC_MEMORY_ACTIVE_CHUNKS_TABLE).where(
                TOPIC_MEMORY_ACTIVE_CHUNKS_TABLE.c.scope_id == scope_id,
                TOPIC_MEMORY_ACTIVE_CHUNKS_TABLE.c.artifact_id == ref.artifact_id,
            )
        )
        await connection.execute(
            delete(TOPIC_MEMORY_ACTIVE_TOPICS_TABLE).where(
                TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.scope_id == scope_id,
                TOPIC_MEMORY_ACTIVE_TOPICS_TABLE.c.artifact_id == ref.artifact_id,
            )
        )
        await connection.execute(
            insert(TOPIC_MEMORY_ACTIVE_TOPICS_TABLE).values(
                scope_id=scope_id,
                family=TopicMemory.family,
                artifact_id=ref.artifact_id,
                revision=ref.revision,
                title=topic.content.title,
                summary=topic.content.summary,
                searchable_text=projection.topic_searchable_text,
                source_count=len(topic.lineage.sources),
            )
        )
        await connection.execute(
            insert(TOPIC_MEMORY_ACTIVE_CHUNKS_TABLE),
            [
                {
                    "scope_id": scope_id,
                    "family": TopicMemory.family,
                    "artifact_id": ref.artifact_id,
                    "revision": ref.revision,
                    "chunk_ordinal": chunk.ordinal,
                    "start_offset": chunk.start_offset,
                    "end_offset": chunk.end_offset,
                    "chunk_text": chunk.text,
                    "searchable_text": analyze_text(chunk.text),
                    "policy_version": chunk.policy_version,
                }
                for chunk in projection.chunks
            ],
        )
        return published_at

    def _validate_projection(
        self,
        draft: TopicMemoryDraft,
        projection: TopicMemoryProjection,
    ) -> TopicMemoryProjection:
        if projection.content != draft.content:
            raise TopicMemoryProjectionError("content")
        if projection.chunks != chunk_topic_memory_detail(draft.content.detail):
            raise TopicMemoryProjectionError("chunks")
        if projection.topic_searchable_text != analyze_text(f"{draft.content.title}\n{draft.content.summary}"):
            raise TopicMemoryProjectionError("lexical")
        capabilities = self.index.capabilities
        if not capabilities.fts:
            raise TopicMemoryProjectionError("fts")
        return self._canonical_vector_projection(projection)

    def _canonical_vector_projection(self, projection: TopicMemoryProjection) -> TopicMemoryProjection:
        capabilities = self.index.capabilities
        has_vectors = projection.topic_embedding is not None or bool(projection.chunk_embeddings)
        if not capabilities.vector:
            if has_vectors or projection.embedding_profile is not None:
                raise TopicMemoryProjectionError("vector-unconfigured")
            return projection
        if projection.topic_embedding is None or len(projection.chunk_embeddings) != len(projection.chunks):
            raise TopicMemoryProjectionError("vector-incomplete")
        if projection.embedding_profile != capabilities.embedding_profile:
            raise TopicMemoryProjectionError("embedding-profile")
        profile = capabilities.embedding_profile
        if profile is None:
            raise TopicMemoryProjectionError("embedding-profile")
        try:
            topic_embedding = canonical_embedding(
                projection.topic_embedding,
                dimension=profile.dimension,
                normalization=profile.normalization,
            )
            chunk_embeddings = tuple(
                canonical_embedding(
                    embedding,
                    dimension=profile.dimension,
                    normalization=profile.normalization,
                )
                for embedding in projection.chunk_embeddings
            )
        except ValueError:
            raise TopicMemoryProjectionError("embedding-values") from None
        return projection.model_copy(
            update={
                "topic_embedding": topic_embedding,
                "chunk_embeddings": chunk_embeddings,
            }
        )

    def _configured_retrieval_shape(self) -> tuple[str, str | None]:
        capabilities = self.index.capabilities
        shape = "hybrid" if capabilities.vector else "fts"
        profile = capabilities.embedding_profile
        fingerprint = None if profile is None else topic_memory_embedding_profile_fingerprint(profile)
        return shape, fingerprint

    def _require_retrieval_shape(self, stored_shape: str, stored_fingerprint: str | None) -> None:
        shape, fingerprint = self._configured_retrieval_shape()
        if (stored_shape, stored_fingerprint) != (shape, fingerprint):
            stored_label = stored_shape if stored_fingerprint is None else f"{stored_shape}:{stored_fingerprint[:12]}"
            configured_label = shape if fingerprint is None else f"{shape}:{fingerprint[:12]}"
            raise TopicMemoryCapabilityError(
                "retrieval-shape",
                f"database requires {stored_label}; runtime configured {configured_label}",
            )

    async def _check_retrieval_shape(self, connection: AsyncConnection) -> None:
        # Reads must neither initialize/reconfigure the store nor take its write
        # lock. Check before and after hydration: SQLite's legacy SELECT mode
        # need not hold a read snapshot across statements. A newly published
        # Topic freezes the shape, so a racing switch cannot silently label
        # another profile's results with this runtime's startup capabilities.
        if not self.index.capabilities.fts:
            return
        stored = (
            await connection.execute(
                select(
                    TOPIC_MEMORY_RETRIEVAL_SHAPE_TABLE.c.shape,
                    TOPIC_MEMORY_RETRIEVAL_SHAPE_TABLE.c.profile_fingerprint,
                ).where(TOPIC_MEMORY_RETRIEVAL_SHAPE_TABLE.c.singleton == 1)
            )
        ).one_or_none()
        if stored is None:
            raise TopicMemoryStorageInvariantError("missing-retrieval-shape", 1)
        self._require_retrieval_shape(str(stored[0]), None if stored[1] is None else str(stored[1]))

    async def _ensure_retrieval_shape(self, connection: AsyncConnection, *, allow_empty_change: bool = False) -> None:
        if not self.index.capabilities.fts:
            return
        shape, fingerprint = self._configured_retrieval_shape()
        # Serialize empty-store reconfiguration with publication. An already
        # open runtime must not publish its old shape after another one changes
        # it. SQLite needs a write lock; SELECT FOR UPDATE is a no-op there.
        await connection.execute(
            update(TOPIC_MEMORY_RETRIEVAL_SHAPE_TABLE)
            .where(TOPIC_MEMORY_RETRIEVAL_SHAPE_TABLE.c.singleton == 1)
            .values(shape=TOPIC_MEMORY_RETRIEVAL_SHAPE_TABLE.c.shape)
        )
        stored = (
            await connection.execute(
                select(
                    TOPIC_MEMORY_RETRIEVAL_SHAPE_TABLE.c.shape,
                    TOPIC_MEMORY_RETRIEVAL_SHAPE_TABLE.c.profile_fingerprint,
                )
                .where(TOPIC_MEMORY_RETRIEVAL_SHAPE_TABLE.c.singleton == 1)
                .with_for_update()
            )
        ).one_or_none()
        if stored is None:
            existing = int(
                await connection.scalar(
                    select(func.count())
                    .select_from(ARTIFACTS_TABLE)
                    .where(ARTIFACTS_TABLE.c.family == TopicMemory.family)
                )
                or 0
            )
            if existing:
                raise TopicMemoryStorageInvariantError("missing-retrieval-shape", existing)
            values = {
                "singleton": 1,
                "shape": shape,
                "profile_fingerprint": fingerprint,
            }
            if connection.dialect.name == "sqlite":
                statement = sqlite_insert(TOPIC_MEMORY_RETRIEVAL_SHAPE_TABLE).values(**values).on_conflict_do_nothing()
            elif connection.dialect.name == "mysql":
                statement = mysql_insert(TOPIC_MEMORY_RETRIEVAL_SHAPE_TABLE).values(**values).prefix_with("IGNORE")
            else:
                statement = insert(TOPIC_MEMORY_RETRIEVAL_SHAPE_TABLE).values(**values)
            await connection.execute(statement)
            stored = (
                await connection.execute(
                    select(
                        TOPIC_MEMORY_RETRIEVAL_SHAPE_TABLE.c.shape,
                        TOPIC_MEMORY_RETRIEVAL_SHAPE_TABLE.c.profile_fingerprint,
                    ).where(TOPIC_MEMORY_RETRIEVAL_SHAPE_TABLE.c.singleton == 1)
                )
            ).one_or_none()
            if stored is None:
                raise TopicMemoryStorageInvariantError("missing-retrieval-shape", 1)
        stored_shape = str(stored[0])
        stored_fingerprint = None if stored[1] is None else str(stored[1])
        if (stored_shape, stored_fingerprint) != (shape, fingerprint):
            if allow_empty_change:
                # A locking read sees publications committed before we obtained
                # the shape lock even on MySQL REPEATABLE READ connections.
                existing = await connection.scalar(
                    select(ARTIFACTS_TABLE.c.artifact_id)
                    .where(ARTIFACTS_TABLE.c.family == TopicMemory.family)
                    .limit(1)
                    .with_for_update()
                )
                if existing is None:
                    await connection.execute(
                        update(TOPIC_MEMORY_RETRIEVAL_SHAPE_TABLE)
                        .where(TOPIC_MEMORY_RETRIEVAL_SHAPE_TABLE.c.singleton == 1)
                        .values(shape=shape, profile_fingerprint=fingerprint)
                    )
                    return
            self._require_retrieval_shape(stored_shape, stored_fingerprint)

    def _select_mode(
        self,
        mode: TopicMemorySearchMode,
        query_vector: object,
        embedding_profile: object,
    ) -> TopicMemoryUsedSearchMode:
        capabilities = self.index.capabilities
        selected = "hybrid" if mode == "auto" and capabilities.hybrid and query_vector is not None else mode
        if selected == "auto":
            selected = "fts"
        if selected in {"vector", "hybrid"}:
            if not capabilities.vector:
                raise TopicMemoryCapabilityError(selected)
            if query_vector is None or embedding_profile != capabilities.embedding_profile:
                raise TopicMemoryCapabilityError("embedding-profile")
        if selected not in {"fts", "vector", "hybrid"}:
            raise TopicMemoryCapabilityError(selected)
        return selected

    def _canonical_query_vector(
        self,
        mode: TopicMemoryUsedSearchMode,
        query_vector: tuple[float, ...] | None,
    ) -> tuple[float, ...] | None:
        if mode == "fts":
            return None
        profile = self.index.capabilities.embedding_profile
        if profile is None or query_vector is None:
            raise TopicMemoryCapabilityError("embedding-profile")
        try:
            return canonical_embedding(
                query_vector,
                dimension=profile.dimension,
                normalization=profile.normalization,
            )
        except ValueError:
            raise TopicMemoryCapabilityError("embedding-vector", "query vector is invalid") from None


def _aware_utc(value: object) -> datetime:
    if not isinstance(value, datetime):
        raise TopicMemoryStorageInvariantError("publication-time", value)
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


def _stored_utc(value: datetime) -> datetime:
    return value.astimezone(UTC).replace(tzinfo=None)


__all__ = ["TopicMemoryRepository"]
